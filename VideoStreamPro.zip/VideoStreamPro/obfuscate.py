import os
import base64
import zlib
import random
import string
import shutil
import sys

def generate_random_string(length=8):
    """Generate a random string of letters and digits."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

def obfuscate_file(file_path, output_dir):
    """
    Basic obfuscation for Python files:
    1. Compress the code
    2. Base64 encode it
    3. Create a loader that decodes and executes at runtime
    """
    # Read the original file
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Extract filename without extension
    filename = os.path.basename(file_path)
    module_name = os.path.splitext(filename)[0]
    
    # Compress and encode the content
    compressed = zlib.compress(content.encode('utf-8'))
    encoded = base64.b64encode(compressed).decode('utf-8')
    
    # Create chunks to avoid very long lines
    chunk_size = 76  # Standard base64 line length
    chunks = [encoded[i:i+chunk_size] for i in range(0, len(encoded), chunk_size)]
    
    # Generate random variable names to make reverse engineering harder
    var_encoded = f"_{generate_random_string()}"
    var_decoded = f"_{generate_random_string()}"
    var_decompressed = f"_{generate_random_string()}"
    var_exec = f"_{generate_random_string()}"
    
    # Create obfuscated loader
    loader = f"""# This file is protected by VideoStream's security system
# Attempting to view, modify or reverse engineer this code is prohibited
# Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved

import base64
import zlib
import sys
import os
import builtins
import types
import time
from random import randint

{var_encoded} = (
    {''.join([f'    "{chunk}"\n' for chunk in chunks])}
)

{var_decoded} = base64.b64decode({var_encoded})
{var_decompressed} = zlib.decompress({var_decoded})

# Anti-tampering check
def _security_check():
    # Check if running in debugger
    if any(x.lower() in os.environ.get('PYTHONDEBUG', '').lower() 
           for x in ['debug', 'trace', 'pdb', 'ipdb']):
        sys.exit("Security violation: Debugging not allowed.")
    
    # Check if we're running the right file
    if not any(os.path.basename(__file__) == name 
               for name in ['{filename}', 'app.pyc', 'app.pyo']):
        sys.exit("Security violation: Invalid execution context.")
    
    # Check timestamp to prevent excessive analysis
    global _last_check_time
    current_time = time.time()
    if '_last_check_time' in globals():
        if current_time - _last_check_time < 0.05:
            # Executing too quickly, might be automated analysis
            time.sleep(randint(1, 3))
    _last_check_time = current_time

# Run check
_last_check_time = time.time()
_security_check()

# Override key builtins to prevent easy inspection
original_open = builtins.open
def restricted_open(file, mode='r', *args, **kwargs):
    if file == __file__ and 'r' in mode:
        raise PermissionError("Access denied: Cannot read source file.")
    return original_open(file, mode, *args, **kwargs)
builtins.open = restricted_open

# Execute the decompressed code
{var_exec} = types.ModuleType('{module_name}')
sys.modules['{module_name}'] = {var_exec}
exec({var_decompressed}, {var_exec}.__dict__)
"""

    # Save the obfuscated file
    output_path = os.path.join(output_dir, filename)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(loader)
    
    print(f"Obfuscated: {file_path} -> {output_path}")
    return output_path

def obfuscate_project():
    """Obfuscate the entire project."""
    # Create secure directory
    output_dir = "secure"
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir)
    
    # Python files to obfuscate
    files_to_obfuscate = [
        'app.py',
        'data_manager.py',
        'stream_converter.py',
        'utils.py',
        'video_service.py'
    ]
    
    # Obfuscate each file
    for file_path in files_to_obfuscate:
        if os.path.exists(file_path):
            obfuscate_file(file_path, output_dir)
    
    # Copy static files and directories
    static_dirs = ['static']
    for static_dir in static_dirs:
        if os.path.exists(static_dir):
            dest_dir = os.path.join(output_dir, static_dir)
            if os.path.exists(dest_dir):
                shutil.rmtree(dest_dir)
            shutil.copytree(static_dir, dest_dir)
            print(f"Copied: {static_dir} -> {dest_dir}")
    
    # Create a starter script
    starter_script = """#!/usr/bin/env python
# VideoStream Secure Launcher
# Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved

import os
import sys
import time
import random
import streamlit.web.cli as stcli

def run_app():
    # Show startup message
    print("="*60)
    print("VideoStream CMS - Secure Edition")
    print("Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved")
    print("Starting application...")
    print("="*60)
    
    # Run the application
    sys.argv = ["streamlit", "run", "app.py", "--server.port=5000", 
                "--server.headless=true", "--server.address=0.0.0.0"]
    sys.exit(stcli.main())

if __name__ == "__main__":
    run_app()
"""
    
    with open(os.path.join(output_dir, "start.py"), 'w', encoding='utf-8') as f:
        f.write(starter_script)
    print(f"Created launcher: {output_dir}/start.py")
    
    # Create README file
    readme = """# VideoStream - Secure Edition

This is the secured version of the VideoStream application.

## How to Run

To run the application, use the following command:

```
cd secure
python start.py
```

## Security Notes

1. The code has been obfuscated to protect intellectual property
2. Do not modify or delete any files in this directory
3. Attempting to view, modify or reverse engineer the code is prohibited
"""
    
    with open(os.path.join(output_dir, "README.md"), 'w') as f:
        f.write(readme)
    print(f"Created README: {output_dir}/README.md")
    
    print("\nObfuscation completed successfully!")
    print(f"The secured application is available in the '{output_dir}' directory.")
    print("To run the secured app, use: cd secure && python start.py")

if __name__ == "__main__":
    obfuscate_project()