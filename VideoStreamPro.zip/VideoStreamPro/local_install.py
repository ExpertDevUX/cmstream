#!/usr/bin/env python3
"""
VideoStream CMS - Local Installation Script
==========================================
This script sets up VideoStream CMS in a local directory structure
for testing or development purposes.
"""

import os
import sys
import shutil
import subprocess
import platform
import venv
import argparse
import json

# Default configuration
DEFAULT_CONFIG = {
    'base_dir': './videostream_local',
    'media_dir': './videostream_local/media',
    'hls_dir': './videostream_local/media/hls',
    'dash_dir': './videostream_local/media/dash',
    'mp4_dir': './videostream_local/media/mp4',
    'thumbnails_dir': './videostream_local/media/thumbnails',
}

def print_colored(text, color):
    """Print colored text to the console"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'purple': '\033[95m',
        'end': '\033[0m',
        'bold': '\033[1m'
    }
    print(f"{colors.get(color, '')}{text}{colors['end']}")

def create_directory_structure(config):
    """Create the necessary directory structure"""
    print_colored("Creating directory structure...", "blue")
    
    for key, directory in config.items():
        if 'dir' in key and directory:
            os.makedirs(directory, exist_ok=True)
            print(f"Created directory: {directory}")
    
    print_colored("Directory structure created successfully!", "green")

def setup_virtual_environment(config):
    """Set up a Python virtual environment"""
    print_colored("\nSetting up Python virtual environment...", "blue")
    
    venv_dir = os.path.join(config['base_dir'], 'venv')
    
    if os.path.exists(venv_dir):
        print(f"Virtual environment already exists at {venv_dir}")
    else:
        print(f"Creating virtual environment at {venv_dir}...")
        venv.create(venv_dir, with_pip=True)
    
    # Determine pip path based on OS
    if platform.system() == 'Windows':
        pip_path = os.path.join(venv_dir, 'Scripts', 'pip')
    else:
        pip_path = os.path.join(venv_dir, 'bin', 'pip')
    
    # Install required packages
    print("Installing required packages...")
    packages = [
        'streamlit',
        'deep-translator',
        'ffmpeg-python',
        'googletrans-py',
        'm3u8',
        'pandas',
        'requests',
        'streamlink',
        'streamlit-option-menu',
        'streamlit-player'
    ]
    
    for package in packages:
        try:
            print(f"Installing {package}...")
            subprocess.run([pip_path, 'install', package], check=True)
        except subprocess.CalledProcessError:
            print_colored(f"Failed to install {package}. Please install it manually.", "red")
    
    print_colored("Python virtual environment setup complete!", "green")

def copy_application_files(config):
    """Copy application files to the local directory"""
    print_colored("\nCopying application files...", "blue")
    
    # Current directory (where this script is running)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Files to copy
    files = [
        'app.py',
        'data_manager.py',
        'stream_converter.py',
        'utils.py',
        'video_service.py'
    ]
    
    # Directories to copy
    dirs = [
        'static'
    ]
    
    # Copy files
    for file in files:
        src = os.path.join(current_dir, file)
        dst = os.path.join(config['base_dir'], file)
        
        if os.path.exists(src):
            shutil.copy2(src, dst)
            print(f"Copied {file}")
        else:
            print_colored(f"Warning: File {file} not found", "yellow")
    
    # Copy directories
    for directory in dirs:
        src = os.path.join(current_dir, directory)
        dst = os.path.join(config['base_dir'], directory)
        
        if os.path.exists(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            print(f"Copied directory {directory}")
        else:
            print_colored(f"Warning: Directory {directory} not found", "yellow")
    
    print_colored("Application files copied successfully!", "green")

def create_streamlit_config(config):
    """Create Streamlit configuration file"""
    print_colored("\nCreating Streamlit configuration...", "blue")
    
    streamlit_dir = os.path.join(config['base_dir'], '.streamlit')
    os.makedirs(streamlit_dir, exist_ok=True)
    
    config_content = """[server]
headless = true
address = "0.0.0.0"
port = 5000
"""
    
    config_path = os.path.join(streamlit_dir, 'config.toml')
    with open(config_path, 'w') as f:
        f.write(config_content)
    
    print(f"Created Streamlit configuration at {config_path}")
    print_colored("Streamlit configuration created successfully!", "green")

def create_start_script(config):
    """Create a startup script"""
    print_colored("\nCreating startup script...", "blue")
    
    # Determine Python path based on OS
    if platform.system() == 'Windows':
        python_path = os.path.join(config['base_dir'], 'venv', 'Scripts', 'python')
        script_ext = '.bat'
    else:
        python_path = os.path.join(config['base_dir'], 'venv', 'bin', 'python')
        script_ext = '.sh'
    
    # Create startup script
    script_path = os.path.join(config['base_dir'], f"start{script_ext}")
    
    if platform.system() == 'Windows':
        script_content = f"""@echo off
cd {config['base_dir']}
{python_path} -m streamlit run app.py
"""
    else:
        script_content = f"""#!/bin/bash
cd {config['base_dir']}
{python_path} -m streamlit run app.py
"""
    
    with open(script_path, 'w') as f:
        f.write(script_content)
    
    # Make script executable on Unix-like systems
    if platform.system() != 'Windows':
        os.chmod(script_path, 0o755)
    
    print(f"Created startup script at {script_path}")
    print_colored("Startup script created successfully!", "green")

def save_config(config):
    """Save configuration to file"""
    config_path = os.path.join(config['base_dir'], 'local_config.json')
    
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    
    print(f"Saved configuration to {config_path}")

def main():
    """Main entry point for the script"""
    parser = argparse.ArgumentParser(description='VideoStream CMS Local Installation Script')
    parser.add_argument('--dir', type=str, help='Base directory for installation', default=DEFAULT_CONFIG['base_dir'])
    args = parser.parse_args()
    
    # Update configuration with command-line argument
    config = DEFAULT_CONFIG.copy()
    if args.dir:
        config['base_dir'] = args.dir
        config['media_dir'] = os.path.join(args.dir, 'media')
        config['hls_dir'] = os.path.join(args.dir, 'media', 'hls')
        config['dash_dir'] = os.path.join(args.dir, 'media', 'dash')
        config['mp4_dir'] = os.path.join(args.dir, 'media', 'mp4')
        config['thumbnails_dir'] = os.path.join(args.dir, 'media', 'thumbnails')
    
    # Print banner
    print_colored("\n====== VideoStream CMS - Local Installation ======\n", "purple")
    
    # Run installation steps
    create_directory_structure(config)
    setup_virtual_environment(config)
    copy_application_files(config)
    create_streamlit_config(config)
    create_start_script(config)
    save_config(config)
    
    # Print completion message
    print_colored("\n====== Installation Complete! ======\n", "purple")
    print("To start VideoStream CMS:")
    
    if platform.system() == 'Windows':
        print(f"  Run: {os.path.join(config['base_dir'], 'start.bat')}")
    else:
        print(f"  Run: {os.path.join(config['base_dir'], 'start.sh')}")
    
    print("\nYour application will be available at: http://localhost:5000")
    print_colored("\nThank you for installing VideoStream CMS!", "green")

if __name__ == "__main__":
    main()