import os
import sys
import platform
import uuid
import hashlib
import datetime

# This is a simple license verification system
# In a real application, you'd want to use a more sophisticated approach

def get_hardware_id():
    """Generate a unique hardware ID based on machine properties."""
    try:
        # Get various system identifiers
        system_info = platform.uname()
        machine_id = f"{system_info.node}-{system_info.system}-{system_info.machine}"
        
        # Create a hash from the machine ID
        hash_obj = hashlib.sha256(machine_id.encode())
        hardware_id = hash_obj.hexdigest()[:16]
        
        return hardware_id
    except:
        # Return a fallback ID if there's an error
        return "default-hw-id"

def generate_license_key(hardware_id, expiry_date=None):
    """Generate a license key for the given hardware ID."""
    if expiry_date is None:
        # Default expiration: 1 year from now
        expiry_date = datetime.datetime.now() + datetime.timedelta(days=365)
    
    expiry_str = expiry_date.strftime("%Y%m%d")
    
    # Combine hardware ID and expiry date
    base = f"{hardware_id}:{expiry_str}"
    
    # Generate a hash
    hash_obj = hashlib.sha256(base.encode())
    license_key = hash_obj.hexdigest()
    
    return f"{license_key[:8]}-{license_key[8:16]}-{license_key[16:24]}-{license_key[24:32]}"

def validate_license(license_key, hardware_id=None):
    """
    Placeholder for license validation.
    In a real application, this would check against a secure license server.
    """
    # For demo purposes, we'll consider any well-formed license key valid
    # In a real system, you'd verify the license key against the hardware ID
    
    # For demonstration, we'll accept any key with the right format
    if len(license_key.split('-')) == 4 and all(len(part) == 8 for part in license_key.split('-')):
        return True
    
    return False

def check_license():
    """Check if a valid license exists for this hardware."""
    license_file = "videostream.license"
    hardware_id = get_hardware_id()
    
    # If license file exists, validate it
    if os.path.exists(license_file):
        try:
            with open(license_file, "r") as f:
                license_key = f.read().strip()
            
            if validate_license(license_key, hardware_id):
                return True
            else:
                print("Invalid license. Please contact support to obtain a valid license.")
                return False
        except:
            pass
    
    # No valid license found
    print("No license found. Generating a temporary development license.")
    
    # Generate a temporary license for development
    license_key = generate_license_key(hardware_id)
    
    try:
        with open(license_file, "w") as f:
            f.write(license_key)
        print(f"Temporary license generated: {license_key}")
        return True
    except:
        print("Could not generate license file. Please run with appropriate permissions.")
        return False

if __name__ == "__main__":
    hardware_id = get_hardware_id()
    print(f"Hardware ID: {hardware_id}")
    
    license_key = generate_license_key(hardware_id)
    print(f"Sample License Key: {license_key}")
    
    is_valid = validate_license(license_key, hardware_id)
    print(f"License validation: {'Valid' if is_valid else 'Invalid'}")