#!/usr/bin/env python3
"""
Test script for VideoStream CMS local installation
This simply creates a test directory structure without installing packages
"""

import os
import sys
import shutil
import json

def print_colored(text, color):
    """Print colored text to the console"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'purple': '\033[95m',
        'end': '\033[0m',
        'bold': '\033[1m'
    }
    print(f"{colors.get(color, '')}{text}{colors['end']}")

def test_directory_creation():
    """Test creating the directory structure"""
    print_colored("Testing directory creation...", "blue")
    
    # Define test directories
    test_dir = "./test_videostream"
    directories = [
        test_dir,
        os.path.join(test_dir, "media"),
        os.path.join(test_dir, "media", "hls"),
        os.path.join(test_dir, "media", "dash"),
        os.path.join(test_dir, "media", "mp4"),
        os.path.join(test_dir, "media", "thumbnails"),
        os.path.join(test_dir, "static"),
        os.path.join(test_dir, ".streamlit")
    ]
    
    # Create directories
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            print(f"Created directory: {directory}")
        except Exception as e:
            print_colored(f"Error creating directory {directory}: {str(e)}", "red")
            return False
    
    # Create a test file in each directory
    for directory in directories:
        test_file = os.path.join(directory, "test.txt")
        try:
            with open(test_file, 'w') as f:
                f.write("This is a test file for VideoStream CMS installation")
            print(f"Created test file: {test_file}")
        except Exception as e:
            print_colored(f"Error creating test file {test_file}: {str(e)}", "red")
            return False
    
    # Create a streamlit config file
    streamlit_config = os.path.join(test_dir, ".streamlit", "config.toml")
    try:
        with open(streamlit_config, 'w') as f:
            f.write("""[server]
headless = true
address = "0.0.0.0"
port = 5000
""")
        print(f"Created Streamlit config: {streamlit_config}")
    except Exception as e:
        print_colored(f"Error creating Streamlit config: {str(e)}", "red")
        return False
    
    # Create a configuration file
    config_file = os.path.join(test_dir, "config.json")
    config = {
        "base_dir": test_dir,
        "media_dir": os.path.join(test_dir, "media"),
        "hls_dir": os.path.join(test_dir, "media", "hls"),
        "dash_dir": os.path.join(test_dir, "media", "dash"),
        "mp4_dir": os.path.join(test_dir, "media", "mp4"),
        "thumbnails_dir": os.path.join(test_dir, "media", "thumbnails")
    }
    
    try:
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=4)
        print(f"Created config file: {config_file}")
    except Exception as e:
        print_colored(f"Error creating config file: {str(e)}", "red")
        return False
    
    print_colored("All directories and files created successfully!", "green")
    return True

def main():
    """Main function"""
    print_colored("\n====== VideoStream CMS - Installation Test ======\n", "purple")
    
    if test_directory_creation():
        print_colored("\nTest completed successfully!", "green")
        print("\nDirectory structure created at ./test_videostream")
        print("You can verify that all directories and files were created correctly.")
    else:
        print_colored("\nTest failed. See error messages above.", "red")
    
    print_colored("\n====== Test Complete ======\n", "purple")

if __name__ == "__main__":
    main()