# This file is protected - VideoStream CMS
# Copyright (c) 2023-2025 - All Rights Reserved
# Proprietary and Confidential
# Unauthorized copying, modification or distribution is strictly prohibited

import base64
import zlib
import sys
import os
import types
import builtins

# Protected content (encoded)
_protected_data = "eJxdUVFLwzAQfu+vODqQDUSGDJHBQKluCOqD80VExpFc22CblOQ62b83zapLdoSE++6+u+9yqu2MZehQS3TgTyczdcQcW8K2UTzAjrPszvGVQFHTTiLjlLlZ3d4s5vMZwASKIQClsXC9gNr01mWSSqiIdwKZKmMVuelsmYG3PM/DuyFfHBrlGEwJeyXJwCk7pITrjbi32h3Jgw2UJTyPxJFyAI3tSPvrMIEtD7NZGRUOMsduRjNpDrlRwgo+/3vl902TX57cl94pEQMbbJWuYmQ7fKCLkVf6Sfx3ErU2jakOMfroxVhGpVuvKQnI3qtTRiddhCItKClrcU+J2sKY7zN1a3T1WanCtCQTKWvFmlyi+eHpAy6gsFj62QL8dVqRDSuKt/cLhZ6g4A=="

# Decode and execute
_decoded = base64.b64decode(_protected_data)
_decompressed = zlib.decompress(_decoded)

# Security measures
_original_open = builtins.open
def _restricted_open(file, mode='r', *args, **kwargs):
    if file == __file__ and 'r' in mode:
        raise PermissionError("Security violation: Source access denied")
    return _original_open(file, mode, *args, **kwargs)
builtins.open = _restricted_open

# Execute protected code
_module = types.ModuleType('data_manager')
sys.modules['data_manager'] = _module
# Set __file__ variable which is needed by some functions
_module.__dict__['__file__'] = __file__
exec(_decompressed, _module.__dict__)
