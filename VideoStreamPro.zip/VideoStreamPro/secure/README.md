# VideoStream CMS - Secure Edition

This is the secured version of VideoStream CMS.

## Running the Application

To run the secured application:

```
cd secure
python start.py
```

## Security Notice

The code in this directory is protected by security measures.
Attempting to view, modify, or reverse-engineer the code is prohibited.

Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved
