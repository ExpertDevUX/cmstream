#!/usr/bin/env python
# VideoStream Secure Launcher
# Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved

import os
import sys
import streamlit.web.cli as stcli

print("="*60)
print("VideoStream CMS - Secure Edition")
print("Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved")
print("Starting secure application...")
print("="*60)

# Anti-inspection measures
import builtins
_original_open = builtins.open
def _restricted_open(file, mode='r', *args, **kwargs):
    # Prevent reading source files
    if any(file.endswith(ext) for ext in ['.py']) and 'r' in mode:
        # Allow certain files to be read
        if not any(os.path.basename(file) == f for f in ['start.py']):
            raise PermissionError(f"Security violation: Source access denied for {file}")
    return _original_open(file, mode, *args, **kwargs)
builtins.open = _restricted_open

# Run the application
sys.argv = ["streamlit", "run", "app.py", "--server.port=5000", 
            "--server.headless=true", "--server.address=0.0.0.0"]
sys.exit(stcli.main())
