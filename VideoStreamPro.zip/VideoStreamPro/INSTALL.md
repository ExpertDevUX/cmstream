# VideoStream CMS - Installation Guide

This guide will help you install and configure VideoStream CMS on your server. The installation script handles dependencies, directory creation, permissions, SSL, Nginx configuration, and systemd service setup.

## Quick Start

For a fully automated installation with the most common settings:

```bash
# Clone the repository
git clone https://github.com/yourusername/videostream-cms.git
cd videostream-cms

# Make the installer executable
chmod +x install.py

# Run the installer as root (recommended)
sudo python3 install.py
```

Follow the interactive prompts to configure your installation.

## Installation Options

### Interactive Installation (Recommended)

```bash
sudo python3 install.py
```

The installer will ask you for configuration options including:
- Installation directory
- Application port
- Domain name
- SSL configuration
- Nginx setup
- Service installation

### Non-Interactive Installation

You can run a non-interactive installation with default settings:

```bash
sudo python3 install.py --non-interactive
```

### Custom Configuration File

You can also provide a custom configuration file:

```bash
sudo python3 install.py --config my_config.json
```

Example configuration file (`my_config.json`):
```json
{
    "server_dir": "/var/www/videostream",
    "port": 5000,
    "domain": "stream.example.com",
    "ssl_enabled": true,
    "use_nginx": true,
    "auto_start": true,
    "install_service": true,
    "setup_permissions": true
}
```

## SSL Configuration

If you choose to enable SSL (HTTPS), the installer will:

1. Verify domain ownership using DNS TXT records
2. Install Certbot (Let's Encrypt client)
3. Generate SSL certificates
4. Configure Nginx for HTTPS
5. Set up automatic certificate renewal

### DNS Verification

When configuring SSL, you'll need to add a TXT record to your domain's DNS settings:

- Record Type: TXT
- Host/Name: _videostream-verify.yourdomain.com
- Value: The verification code provided by the installer

This proves you control the domain and allows secure HTTPS connections.

## Installation Steps

The installer performs the following steps:

1. Checks and installs required dependencies
2. Creates necessary directories
3. Sets appropriate permissions
4. Sets up Python virtual environment
5. Copies application files
6. Configures SSL (if enabled)
7. Configures Nginx (if enabled)
8. Creates a systemd service
9. Saves the configuration

## Directory Structure

After installation, the following directories will be available:

- Main application: `/var/www/videostream/` (default)
- HLS streams: `/var/www/videostream/hls/`
- DASH streams: `/var/www/videostream/dash/`
- MP4 files: `/var/www/videostream/mp4/`
- Thumbnails: `/var/www/videostream/thumbnails/`

## Managing the Service

The installer creates a systemd service for VideoStream CMS. You can manage it with these commands:

```bash
# Start the service
sudo systemctl start videostream

# Stop the service
sudo systemctl stop videostream

# Restart the service
sudo systemctl restart videostream

# Check service status
sudo systemctl status videostream

# View logs
sudo journalctl -u videostream
```

## Manual Installation

If you prefer to install manually, follow these steps:

1. Install dependencies:
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv ffmpeg nginx
   ```

2. Create directories:
   ```bash
   sudo mkdir -p /var/www/videostream/{hls,dash,mp4,thumbnails}
   ```

3. Set permissions:
   ```bash
   sudo chown -R youruser:www-data /var/www/videostream
   sudo find /var/www/videostream -type d -exec chmod 755 {} \;
   sudo find /var/www/videostream -type f -exec chmod 644 {} \;
   ```

4. Setup Python environment:
   ```bash
   python3 -m venv /var/www/videostream/venv
   /var/www/videostream/venv/bin/pip install streamlit deep-translator ffmpeg-python googletrans-py m3u8 pandas requests streamlink streamlit-option-menu streamlit-player
   ```

5. Copy application files to `/var/www/videostream/`

6. Configure Nginx (create `/etc/nginx/sites-available/videostream`):
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;
       
       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
       
       location /hls/ {
           alias /var/www/videostream/hls/;
           add_header Cache-Control no-cache;
           add_header Access-Control-Allow-Origin *;
       }
       
       # Add similar blocks for /dash/, /mp4/, and /thumbnails/
   }
   ```

7. Enable the Nginx configuration:
   ```bash
   sudo ln -s /etc/nginx/sites-available/videostream /etc/nginx/sites-enabled/
   sudo systemctl restart nginx
   ```

8. Create a systemd service (create `/etc/systemd/system/videostream.service`):
   ```
   [Unit]
   Description=VideoStream CMS
   After=network.target
   
   [Service]
   User=youruser
   WorkingDirectory=/var/www/videostream
   ExecStart=/var/www/videostream/venv/bin/python -m streamlit run app.py --server.port=5000 --server.address=0.0.0.0 --server.headless=true
   Restart=on-failure
   
   [Install]
   WantedBy=multi-user.target
   ```

9. Enable and start the service:
   ```bash
   sudo systemctl enable videostream
   sudo systemctl start videostream
   ```

## Troubleshooting

### Application Not Starting
- Check the service status: `sudo systemctl status videostream`
- View the logs: `sudo journalctl -u videostream`
- Verify Python dependencies: `~/venv/bin/pip list`

### Nginx Configuration Issues
- Test Nginx configuration: `sudo nginx -t`
- Check Nginx logs: `sudo tail -f /var/log/nginx/error.log`

### Permission Problems
- Ensure the application directories have correct permissions
- The web server user (www-data) needs read access to all files

### SSL/HTTPS Not Working
- Verify certificate paths in Nginx configuration
- Check Certbot logs: `sudo certbot certificates`
- Ensure domain DNS is configured correctly

## Updating VideoStream CMS

To update VideoStream CMS:

1. Stop the service:
   ```bash
   sudo systemctl stop videostream
   ```

2. Backup your current installation:
   ```bash
   sudo cp -r /var/www/videostream /var/www/videostream.bak
   ```

3. Download and install the new version:
   ```bash
   # Replace with your update method (git pull, download new package, etc.)
   cd /path/to/videostream-cms
   git pull
   
   # Copy new files
   sudo cp -r * /var/www/videostream/
   ```

4. Restart the service:
   ```bash
   sudo systemctl start videostream
   ```

## Additional Configuration

### Custom StreamLit Configuration

Create or edit `/var/www/videostream/.streamlit/config.toml`:

```toml
[server]
headless = true
address = "0.0.0.0"
port = 5000

[theme]
primaryColor = "#FF4B4B"
backgroundColor = "#0E1117"
secondaryBackgroundColor = "#262730"
textColor = "#FAFAFA"
```

## Getting Help

If you encounter issues during installation or configuration:

1. Check the troubleshooting section above
2. Review the application logs
3. Visit our GitHub repository for help and updates
4. Open an issue if you've found a bug

---

Thank you for installing VideoStream CMS!