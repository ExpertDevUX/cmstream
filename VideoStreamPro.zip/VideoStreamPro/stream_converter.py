import os
import tempfile
import uuid
import subprocess
import ffmpeg
import m3u8
import streamlink
from pathlib import Path
import streamlit as st

# Define storage paths for output files
OUTPUT_DIR = 'static/outputs'
os.makedirs(OUTPUT_DIR, exist_ok=True)

@st.cache_data(ttl=1800)  # Cache for 30 minutes
def validate_rtmp_stream(rtmp_url):
    """
    Validate if the RTMP URL is accessible
    
    Args:
        rtmp_url (str): RTMP stream URL
        
    Returns:
        bool: True if the stream is valid and accessible
    """
    try:
        # Use ffmpeg to check if the RTMP stream is valid
        probe = ffmpeg.probe(rtmp_url, v='error', timeout=10)
        return True
    except Exception as e:
        print(f"Error validating RTMP stream: {e}")
        return False

def create_preview_thumbnail(rtmp_url, output_path=None):
    """
    Create a preview thumbnail from an RTMP stream
    
    Args:
        rtmp_url (str): RTMP stream URL
        output_path (str, optional): Path to save the thumbnail
        
    Returns:
        str: Path to the generated thumbnail
    """
    if not output_path:
        output_path = os.path.join(OUTPUT_DIR, f"preview_{uuid.uuid4()}.jpg")
    
    try:
        # Use ffmpeg to capture a frame from the stream
        ffmpeg.input(rtmp_url, ss=2).output(
            output_path, vframes=1, format='image2', vcodec='mjpeg'
        ).run(capture_stdout=True, capture_stderr=True, overwrite_output=True)
        
        return output_path
    except Exception as e:
        print(f"Error creating preview: {e}")
        return None

def convert_rtmp_to_hls(rtmp_url, output_name=None):
    """
    Convert RTMP stream to HLS format
    
    Args:
        rtmp_url (str): RTMP stream URL
        output_name (str, optional): Base name for output files
        
    Returns:
        dict: Dictionary with paths to the generated HLS files
    """
    if not output_name:
        output_name = f"stream_{uuid.uuid4()}"
    
    output_dir = os.path.join(OUTPUT_DIR, output_name)
    os.makedirs(output_dir, exist_ok=True)
    
    playlist_path = os.path.join(output_dir, "playlist.m3u8")
    
    try:
        # Use ffmpeg to convert RTMP to HLS
        command = [
            'ffmpeg', '-i', rtmp_url, 
            '-c:v', 'libx264', '-c:a', 'aac', 
            '-f', 'hls', 
            '-hls_time', '4',
            '-hls_playlist_type', 'event',
            '-hls_list_size', '10',
            playlist_path
        ]
        
        # Start the conversion process
        process = subprocess.Popen(
            command, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        
        # Return paths immediately and let the process run in background
        return {
            'type': 'hls',
            'playlist_path': playlist_path,
            'base_url': f"/outputs/{output_name}/",
            'process': process,
            'output_dir': output_dir
        }
    except Exception as e:
        print(f"Error converting RTMP to HLS: {e}")
        return None

def convert_rtmp_to_dash(rtmp_url, output_name=None):
    """
    Convert RTMP stream to DASH format
    
    Args:
        rtmp_url (str): RTMP stream URL
        output_name (str, optional): Base name for output files
        
    Returns:
        dict: Dictionary with paths to the generated DASH files
    """
    if not output_name:
        output_name = f"stream_{uuid.uuid4()}"
    
    output_dir = os.path.join(OUTPUT_DIR, output_name)
    os.makedirs(output_dir, exist_ok=True)
    
    manifest_path = os.path.join(output_dir, "manifest.mpd")
    
    try:
        # Use ffmpeg to convert RTMP to DASH
        command = [
            'ffmpeg', '-i', rtmp_url, 
            '-c:v', 'libx264', '-c:a', 'aac', 
            '-f', 'dash', 
            '-seg_duration', '4',
            '-use_template', '1',
            '-use_timeline', '1',
            manifest_path
        ]
        
        # Start the conversion process
        process = subprocess.Popen(
            command, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        )
        
        # Return paths immediately and let the process run in background
        return {
            'type': 'dash',
            'manifest_path': manifest_path,
            'base_url': f"/outputs/{output_name}/",
            'process': process,
            'output_dir': output_dir
        }
    except Exception as e:
        print(f"Error converting RTMP to DASH: {e}")
        return None

def convert_rtmp_to_mp4(rtmp_url, duration=30, output_name=None):
    """
    Convert RTMP stream to MP4 format (clip a segment of the stream)
    
    Args:
        rtmp_url (str): RTMP stream URL
        duration (int): Duration of the clip in seconds
        output_name (str, optional): Base name for output file
        
    Returns:
        dict: Dictionary with path to the generated MP4 file
    """
    if not output_name:
        output_name = f"stream_{uuid.uuid4()}"
    
    output_path = os.path.join(OUTPUT_DIR, f"{output_name}.mp4")
    
    try:
        # Use ffmpeg to convert RTMP to MP4 (limited duration)
        command = [
            'ffmpeg', '-i', rtmp_url, 
            '-c:v', 'libx264', '-c:a', 'aac', 
            '-t', str(duration),
            output_path
        ]
        
        # Execute the command and wait for it to complete (since we're clipping)
        subprocess.run(command, check=True, capture_output=True)
        
        return {
            'type': 'mp4',
            'file_path': output_path,
            'base_url': f"/outputs/{output_name}.mp4"
        }
    except Exception as e:
        print(f"Error converting RTMP to MP4: {e}")
        return None

def generate_embed_code(stream_info, width=640, height=360):
    """
    Generate HTML embed code for the converted stream
    
    Args:
        stream_info (dict): Stream information from conversion functions
        width (int): Width of the player
        height (int): Height of the player
        
    Returns:
        str: HTML embed code
    """
    stream_type = stream_info.get('type')
    
    if stream_type == 'hls':
        # HLS embed code using video.js
        return f"""
        <iframe width="{width}" height="{height}" src="https://replit.com/@username/VideoStreamApp/player.html?type=hls&url={stream_info['base_url']}playlist.m3u8" frameborder="0" allowfullscreen></iframe>
        """
    elif stream_type == 'dash':
        # DASH embed code using dash.js
        return f"""
        <iframe width="{width}" height="{height}" src="https://replit.com/@username/VideoStreamApp/player.html?type=dash&url={stream_info['base_url']}manifest.mpd" frameborder="0" allowfullscreen></iframe>
        """
    elif stream_type == 'mp4':
        # Direct MP4 embed
        return f"""
        <iframe width="{width}" height="{height}" src="https://replit.com/@username/VideoStreamApp/player.html?type=mp4&url={stream_info['base_url']}" frameborder="0" allowfullscreen></iframe>
        """
    else:
        return "Unsupported stream type"

def stop_conversion_process(stream_info):
    """
    Stop an ongoing conversion process
    
    Args:
        stream_info (dict): Stream information from conversion functions
        
    Returns:
        bool: True if process was stopped successfully
    """
    if 'process' in stream_info and stream_info['process']:
        try:
            process = stream_info['process']
            process.terminate()
            return True
        except Exception as e:
            print(f"Error stopping conversion process: {e}")
            return False
    return False

def generate_rtmp_source(use_ssl=False):
    """
    Generate a unique RTMP source for streaming
    
    Args:
        use_ssl (bool): Whether to use SSL (RTMPS) for secure streaming
        
    Returns:
        dict: Dictionary containing RTMP server URL and stream key
    """
    # Generate a unique stream key
    stream_key = str(uuid.uuid4())
    
    # In a real implementation, this would connect to an actual RTMP server
    # For now, we'll provide a simulated URL, with option for SSL
    protocol = "rtmps" if use_ssl else "rtmp"
    domain = "streaming.videostream.com"
    server_url = f"{protocol}://{domain}/live"
    
    # In a production environment, you would register this stream key with your RTMP server
    # and set up the necessary configurations
    
    # Generate a DNS TXT record for SSL verification (simulated)
    verification_code = f"vs-verify-{uuid.uuid4().hex[:16]}"
    txt_record = f"{domain} IN TXT \"{verification_code}\""
    
    # Generate a demo player URL that would work with the stream
    demo_player_url = f"/preview/{stream_key}"
    
    return {
        'server_url': server_url,
        'stream_key': stream_key,
        'full_url': f"{server_url}/{stream_key}",
        'use_ssl': use_ssl,
        'verification_code': verification_code if use_ssl else None,
        'txt_record': txt_record if use_ssl else None,
        'demo_player_url': demo_player_url
    }

def get_obs_instructions(server_url, stream_key):
    """
    Get instructions for connecting with OBS Studio
    
    Args:
        server_url (str): RTMP server URL
        stream_key (str): Stream key
        
    Returns:
        str: Formatted instructions
    """
    return f"""
    1. Open OBS Studio
    2. Go to Settings > Stream
    3. Select "Custom..." as the service
    4. Enter "{server_url}" as the server
    5. Enter "{stream_key}" as the stream key
    6. Click "Apply" and then "OK"
    7. Click "Start Streaming" to begin
    """

def get_wirecast_instructions(server_url, stream_key):
    """
    Get instructions for connecting with Wirecast
    
    Args:
        server_url (str): RTMP server URL
        stream_key (str): Stream key
        
    Returns:
        str: Formatted instructions
    """
    return f"""
    1. Open Wirecast
    2. Click on "Output" > "Output Settings"
    3. Click the "+" button to add a new destination
    4. Select "RTMP Server"
    5. Enter "{server_url}" as the Address
    6. Enter "{stream_key}" as the Stream
    7. Configure other settings as needed
    8. Click "OK" and then click the "Stream" button to start streaming
    """

def get_vmix_instructions(server_url, stream_key):
    """
    Get instructions for connecting with vMix
    
    Args:
        server_url (str): RTMP server URL
        stream_key (str): Stream key
        
    Returns:
        str: Formatted instructions
    """
    return f"""
    1. Open vMix
    2. Click on "Settings" > "External"
    3. Click the "+" button to add a new streaming destination
    4. Select "Custom RTMP Server"
    5. Enter "{server_url}/{stream_key}" as the URL
    6. Configure other settings as needed
    7. Click "OK" and then click "Start Streaming" to begin
    """

def generate_demo_preview_player(stream_key, width=640, height=360):
    """
    Generate HTML for a demo preview player for an RTMP stream
    
    Args:
        stream_key (str): Stream key for the RTMP stream
        width (int): Width of the player
        height (int): Height of the player
        
    Returns:
        str: HTML code for the demo player
    """
    # Create a unique ID for the player
    player_id = f"rtmp-player-{stream_key[:8]}"
    
    # Generate player HTML with multiple source options for better browser compatibility
    html_code = f"""
    <div id="{player_id}" style="width:{width}px;height:{height}px;max-width:100%;">
      <video id="video-{player_id}" controls autoplay style="width:100%;height:100%;">
        <!-- HLS source for modern browsers -->
        <source src="https://demo.videostream.com/hls/{stream_key}/index.m3u8" type="application/x-mpegURL">
        <!-- DASH source for browsers that support it -->
        <source src="https://demo.videostream.com/dash/{stream_key}/manifest.mpd" type="application/dash+xml">
        <!-- Fallback message -->
        Your browser does not support the video tag or the required formats.
      </video>
    </div>
    <script>
      // Player enhancement script
      document.addEventListener('DOMContentLoaded', function() {{
        // Check if player is visible - simulates stream connection
        const checkStream = () => {{
          console.log('Checking for active stream...');
          // In a real implementation, this would check if the stream is active
          // For demo purposes, we'll show a status message
          const statusElement = document.createElement('div');
          statusElement.style.padding = '10px';
          statusElement.style.backgroundColor = 'rgba(0,0,0,0.7)';
          statusElement.style.color = 'white';
          statusElement.style.position = 'absolute';
          statusElement.style.bottom = '10px';
          statusElement.style.left = '10px';
          statusElement.style.borderRadius = '5px';
          statusElement.innerHTML = 'Waiting for stream to start...';
          
          const playerElement = document.getElementById('{player_id}');
          playerElement.style.position = 'relative';
          playerElement.appendChild(statusElement);
          
          // In a real implementation, we would periodically check for the stream
          setTimeout(() => {{
            statusElement.innerHTML = 'No active stream detected. Start streaming from your broadcasting software.';
          }}, 5000);
        }};
        
        checkStream();
      }});
    </script>
    """
    
    return html_code

def verify_ssl_domain(domain, verification_code):
    """
    Simulate verification of a domain for SSL certificate issuance
    
    Args:
        domain (str): Domain to verify
        verification_code (str): Verification code to check in DNS TXT records
        
    Returns:
        bool: True if verification is successful
    """
    # In a real implementation, this would check actual DNS TXT records
    # For demo purposes, we'll simulate a successful verification
    print(f"Simulating verification of {domain} with code {verification_code}")
    
    # Simulate DNS lookup and verification process
    return True