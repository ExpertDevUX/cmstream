import streamlit as st
import pandas as pd
import os
import sys
import inspect
from streamlit.components.v1 import html

# Add security check to prevent tampering
def security_check():
    """Check if the application environment is secure and hasn't been tampered with."""
    # This is a simplified version - in a real app, you'd have more checks
    
    # Check if we're running from the expected file
    executing_file = os.path.basename(sys.argv[0])
    expected_files = ['app.py', 'run_secure_app.py', 'run_streamlit.py']
    if not any(executing_file.endswith(file) for file in expected_files):
        st.error("Security violation: Application launched from unexpected entry point.")
        st.stop()
    
    # Check if source code appears to be tampered with
    current_frame = inspect.currentframe()
    frame_info = inspect.getframeinfo(current_frame)
    source_file = frame_info.filename
    try:
        with open(source_file, 'r') as f:
            file_content = f.read()
            if "security_check()" not in file_content:
                st.error("Security violation: Application integrity check failed.")
                st.stop()
    except:
        # If we can't open the file, we'll assume it's obfuscated/compiled
        pass

# Run security check
security_check()
from video_service import fetch_trending_videos, fetch_video_details, search_videos, fetch_videos_by_category
from data_manager import get_categories
from utils import create_thumbnail_link, translate_text, get_translations
from stream_converter import (validate_rtmp_stream, create_preview_thumbnail, 
                            convert_rtmp_to_hls, convert_rtmp_to_dash, 
                            convert_rtmp_to_mp4, generate_embed_code, stop_conversion_process,
                            generate_rtmp_source, get_obs_instructions, 
                            get_wirecast_instructions, get_vmix_instructions)
from streamlit_option_menu import option_menu

# Page configuration
st.set_page_config(
    page_title="VideoStream",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'selected_video' not in st.session_state:
    st.session_state.selected_video = None
if 'current_page' not in st.session_state:
    st.session_state.current_page = "Home"
if 'language' not in st.session_state:
    st.session_state.language = "EN"
if 'donation_confirmed' not in st.session_state:
    st.session_state.donation_confirmed = False
if 'rtmp_url' not in st.session_state:
    st.session_state.rtmp_url = ""
if 'preview_path' not in st.session_state:
    st.session_state.preview_path = None
if 'conversion_result' not in st.session_state:
    st.session_state.conversion_result = None
if 'embed_code' not in st.session_state:
    st.session_state.embed_code = None
if 'contact_form_submitted' not in st.session_state:
    st.session_state.contact_form_submitted = False
    
if 'rtmp_source' not in st.session_state:
    st.session_state.rtmp_source = None

# Get translations for the current language
translations = get_translations(st.session_state.language)

# Add anti-debugging JavaScript
def inject_anti_debug_js():
    """Inject JavaScript to make debugging and code extraction more difficult."""
    anti_debug_js = """
    <script>
    // Disable right-click
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });
    
    // Disable keyboard shortcuts commonly used for inspection
    document.addEventListener('keydown', function(e) {
        // Prevent F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
        if (
            e.keyCode === 123 || 
            (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) ||
            (e.ctrlKey && e.keyCode === 85)
        ) {
            e.preventDefault();
            return false;
        }
    });
    
    // Anti-debugging technique
    (function() {
        function check() {
            const start = new Date();
            debugger;
            const end = new Date();
            if (end - start > 100) {
                // If debugger is open, it will pause longer than 100ms
                document.body.innerHTML = '<h1>Debugging detected! Application terminated.</h1>';
            }
        }
        
        // Check periodically
        setInterval(check, 1000);
        
        // Also check on property access, which can detect DevTools
        const div = document.createElement('div');
        let counter = 0;
        
        // Define a property with a custom getter
        Object.defineProperty(div, 'id', {
            get: function() {
                counter++;
                if (counter > 1) {
                    // Property accessed more times than expected
                    document.body.innerHTML = '<h1>DevTools detected! Application terminated.</h1>';
                }
                return 'id';
            }
        });
        
        // Use console formatting to force property access
        console.log('%c', div);
    })();
    </script>
    """
    st.markdown(anti_debug_js, unsafe_allow_html=True)

# Inject the anti-debugging JavaScript
inject_anti_debug_js()

# Serve static files
@st.cache_data
def serve_static_files():
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    if not os.path.exists(static_dir):
        os.makedirs(static_dir)

serve_static_files()

# Sidebar for navigation and search
with st.sidebar:
    # Display the custom logo
    logo_html = """
    <div style="display: flex; justify-content: center; margin-bottom: 20px;">
        <img src="static/logo.svg" alt="VideoStream Logo" width="180px">
    </div>
    """
    st.markdown(logo_html, unsafe_allow_html=True)
    st.title(f"VideoStream")
    
    # Language selector
    language_options = {"EN": "English", "VN": "Tiếng Việt", "CN": "中文"}
    selected_language = st.selectbox(
        "Select Language" if st.session_state.language == "EN" else 
        "Chọn ngôn ngữ" if st.session_state.language == "VN" else 
        "选择语言",
        options=list(language_options.keys()),
        format_func=lambda x: language_options[x],
        index=list(language_options.keys()).index(st.session_state.language)
    )
    
    if selected_language != st.session_state.language:
        st.session_state.language = selected_language
        st.rerun()
    
    st.divider()
    
    # Get translations for menu items - fixed to always show correctly
    home_text = "Home" if st.session_state.language == "EN" else "Trang chủ" if st.session_state.language == "VN" else "主页"
    converter_text = "Stream Converter" if st.session_state.language == "EN" else "Chuyển đổi luồng" if st.session_state.language == "VN" else "流转换器"
    doc_text = "Documentation" if st.session_state.language == "EN" else "Tài liệu" if st.session_state.language == "VN" else "文档"
    guide_text = "User Guide" if st.session_state.language == "EN" else "Hướng dẫn" if st.session_state.language == "VN" else "用户指南"
    contact_text = "Contact" if st.session_state.language == "EN" else "Liên hệ" if st.session_state.language == "VN" else "联系我们"
    donate_text = "Donate" if st.session_state.language == "EN" else "Ủng hộ" if st.session_state.language == "VN" else "捐赠"
    
    # Main navigation with hardcoded language options to ensure it always works
    selected_page = option_menu(
        menu_title=translations["menu"],
        options=[home_text, converter_text, doc_text, guide_text, contact_text, donate_text],
        icons=["house", "camera-video", "file-text", "info-circle", "envelope", "heart-fill"],
        menu_icon="cast",
        default_index=["Home", "Converter", "Document", "Guide", "Contact", "Donate"].index(st.session_state.current_page),
    )
    
    # Map selected page back to English for session state
    page_mapping = {
        home_text: "Home",
        converter_text: "Converter",
        doc_text: "Document",
        guide_text: "Guide",
        contact_text: "Contact",
        donate_text: "Donate"
    }
    
    if page_mapping[selected_page] != st.session_state.current_page:
        st.session_state.current_page = page_mapping[selected_page]
        st.session_state.selected_video = None
        st.rerun()
    
    st.divider()
    
    # Only show these options on the Home page
    if st.session_state.current_page == "Home":
        # Search functionality
        st.subheader(translations["search_videos"])
        search_query = st.text_input(translations["search_placeholder"])
        search_button = st.button(translations["search_button"])
        
        st.divider()
        
        # Categories navigation
        st.subheader(translations["categories"])
        categories = get_categories()
        # Translate category names
        translated_categories = [translate_text(category, st.session_state.language) for category in categories]
        category_dict = dict(zip(translated_categories, categories))
        
        selected_translated_category = st.selectbox(
            translations["select_category"],
            translated_categories
        )
        # Map back to original category
        selected_category = category_dict[selected_translated_category]

# Main content area
if st.session_state.selected_video:
    # Video player page
    video_id = st.session_state.selected_video
    video_details = fetch_video_details(video_id)
    
    if video_details:
        st.title(video_details['title'])
        
        # Using streamlit-player for video embedding
        import streamlit.components.v1 as components
        from streamlit_player import st_player
        
        # Add branching video control
        if 'video_branch' not in st.session_state:
            st.session_state.video_branch = 'main'
            
        # Create player with branching controls
        player_col, branch_col = st.columns([3, 1])
        
        with player_col:
            # Embed YouTube video
            st_player(f"https://www.youtube.com/watch?v={video_id}", height=450)
        
        with branch_col:
            st.subheader("Video Branches")
            st.write("Choose alternative storylines or content:")
            
            # Branching options
            branches = {
                'main': "Main Content",
                'detailed': "Detailed Explanation",
                'summary': "Quick Summary",
                'beginner': "Beginner Friendly"
            }
            
            selected_branch = st.radio(
                "Select Branch",
                options=list(branches.keys()),
                format_func=lambda x: branches[x],
                index=list(branches.keys()).index(st.session_state.video_branch)
            )
            
            if selected_branch != st.session_state.video_branch:
                st.session_state.video_branch = selected_branch
                # In a full implementation, this would change the video source
                st.info(f"Switched to {branches[selected_branch]} branch")
                
            # Add branch notes
            st.markdown("---")
            st.caption("**Branch Notes:**")
            
            if selected_branch == 'main':
                st.write("Standard video content with balanced information.")
            elif selected_branch == 'detailed':
                st.write("In-depth explanations with technical details.")
            elif selected_branch == 'summary':
                st.write("Key points only, perfect for quick review.")
            elif selected_branch == 'beginner':
                st.write("Simplified content with extra explanations.")
        
        # Video metadata
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader(translations["description"])
            # Translate description if not in English
            if st.session_state.language != "EN":
                translated_description = translate_text(video_details['description'], st.session_state.language)
                st.write(translated_description)
            else:
                st.write(video_details['description'])
        
        with col2:
            st.subheader(translations["details"])
            st.write(f"👁️ {translations['views']}: {video_details['views']}")
            st.write(f"👍 {translations['likes']}: {video_details['likes']}")
            st.write(f"📅 {translations['published']}: {video_details['published_at']}")
            st.write(f"🏷️ {translations['category']}: {translate_text(video_details['category'], st.session_state.language)}")
        
        # Related videos
        st.subheader(translations["related_videos"])
        related_videos = fetch_videos_by_category(video_details['category'], exclude_id=video_id, limit=6)
        
        # Display related videos in a grid
        cols = st.columns(3)
        for idx, video in enumerate(related_videos):
            with cols[idx % 3]:
                st.image(create_thumbnail_link(video['id']), use_column_width=True)
                
                # Translate title if needed
                if st.session_state.language != "EN":
                    video_title = translate_text(video['title'], st.session_state.language)
                else:
                    video_title = video['title']
                    
                display_title = video_title[:40] + "..." if len(video_title) > 40 else video_title
                
                if st.button(display_title, key=f"related_{video['id']}"):
                    st.session_state.selected_video = video['id']
                    st.rerun()
    else:
        st.error(translations["video_unavailable"])
        if st.button(translations["back_to_home"]):
            st.session_state.selected_video = None
            st.rerun()

elif st.session_state.current_page == "Home":
    # Home page with project information
    st.title(translations["welcome"])
    
    # Project Information section (moved from Dashboard)
    st.header(translations.get("project_information", "Project Information"))
    st.subheader(translations.get("open_source_cms", "VideoStream - Open Source CMS"))
    st.write(translations.get("project_description", "VideoStream is an open-source content management system for video streaming platforms. Built with Streamlit, it provides a modern and customizable solution for creating video streaming websites."))
    
    # Project details
    project_col1, project_col2 = st.columns(2)
    with project_col1:
        st.write(translations.get("project_version", "Version: 1.0.0"))
        st.write(translations.get("project_license", "License: MIT"))
    with project_col2:
        st.write(translations.get("project_repository", "GitHub Repository: github.com/videostream/cms"))
    
    # Features overview
    st.header(translations.get("features_overview", "Features Overview"))
    
    # Feature cards
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### " + translations.get("rtmp_conversion", "RTMP Stream Conversion"))
        st.write(translations.get("rtmp_conversion_desc", "Convert RTMP streams to HLS, DASH, or MP4 formats for embedding in websites."))
        
        st.markdown("### " + translations.get("multi_language", "Multi-language Support"))
        st.write(translations.get("multi_language_desc", "Full support for English, Vietnamese, and Chinese languages with automatic translation."))
        
        st.markdown("### " + translations.get("documentation", "Comprehensive Documentation"))
        st.write(translations.get("documentation_desc", "Detailed user guides and documentation for all features."))
    
    with col2:
        st.markdown("### " + translations.get("content_management", "Content Management"))
        st.write(translations.get("content_management_desc", "Browse, search, and organize video content by categories."))
        
        st.markdown("### " + translations.get("embedded_player", "Embeddable Player"))
        st.write(translations.get("embedded_player_desc", "Generate embed codes for including videos in external websites."))
    
    # Display video search results if search was performed
    if search_query and search_button:
        st.divider()
        st.subheader(f"{translations['search_results_for']}: {search_query}")
        search_results = search_videos(search_query)
        
        if search_results:
            # Display search results in a grid
            cols = st.columns(3)
            for idx, video in enumerate(search_results):
                with cols[idx % 3]:
                    st.image(create_thumbnail_link(video['id']), use_column_width=True)
                    
                    # Translate title if needed
                    if st.session_state.language != "EN":
                        video_title = translate_text(video['title'], st.session_state.language)
                    else:
                        video_title = video['title']
                        
                    display_title = video_title[:40] + "..." if len(video_title) > 40 else video_title
                    
                    if st.button(display_title, key=f"search_{video['id']}"):
                        st.session_state.selected_video = video['id']
                        st.rerun()
        else:
            st.info(translations["no_videos_found"])
    
    # Display videos by selected category
    if selected_category != "All":
        st.divider()
        st.subheader(f"{translate_text(selected_category, st.session_state.language)} {translations['videos']}")
        category_videos = fetch_videos_by_category(selected_category)
        
        if category_videos:
            # Display category videos in a grid
            cols = st.columns(3)
            for idx, video in enumerate(category_videos):
                with cols[idx % 3]:
                    st.image(create_thumbnail_link(video['id']), use_column_width=True)
                    
                    # Translate title if needed
                    if st.session_state.language != "EN":
                        video_title = translate_text(video['title'], st.session_state.language)
                    else:
                        video_title = video['title']
                        
                    display_title = video_title[:40] + "..." if len(video_title) > 40 else video_title
                    
                    if st.button(display_title, key=f"cat_{video['id']}"):
                        st.session_state.selected_video = video['id']
                        st.rerun()
        else:
            st.info(f"{translations['no_videos_in_category']} {translate_text(selected_category, st.session_state.language)}")

elif st.session_state.current_page == "Document":
    # Documentation Page
    st.title(translations["documentation"])
    
    st.header(translations["about_videostream"])
    st.write(translations["about_description"])
    
    st.header(translations["features"])
    st.markdown("""
    - **""" + translations["feature_browse"] + """**: """ + translations["feature_browse_desc"] + """
    - **""" + translations["feature_search"] + """**: """ + translations["feature_search_desc"] + """
    - **""" + translations["feature_categories"] + """**: """ + translations["feature_categories_desc"] + """
    - **""" + translations["feature_player"] + """**: """ + translations["feature_player_desc"] + """
    - **""" + translations["feature_translation"] + """**: """ + translations["feature_translation_desc"] + """
    """)
    
    st.header(translations["privacy_policy"])
    st.write(translations["privacy_policy_content"])
    
    st.header(translations["terms_of_service"])
    st.write(translations["terms_of_service_content"])

elif st.session_state.current_page == "Guide":
    # User Guide Page
    st.title(translations["user_guide"])
    
    st.header(translations["getting_started"])
    st.write(translations["getting_started_content"])
    
    st.header(translations["searching_videos"])
    st.write(translations["searching_videos_content"])
    
    st.header(translations["browsing_categories"])
    st.write(translations["browsing_categories_content"])
    
    st.header(translations["watching_videos"])
    st.write(translations["watching_videos_content"])
    
    st.header(translations["language_settings"])
    st.write(translations["language_settings_content"])
    
    st.header(translations["troubleshooting"])
    st.markdown("""
    #### """ + translations["issue_video_not_playing"] + """
    """ + translations["issue_video_not_playing_solution"] + """
    
    #### """ + translations["issue_loading_slow"] + """
    """ + translations["issue_loading_slow_solution"] + """
    
    #### """ + translations["issue_search_not_working"] + """
    """ + translations["issue_search_not_working_solution"] + """
    """)

elif st.session_state.current_page == "Converter":
    # Stream Converter Page
    st.title(translations.get("stream_converter", "Stream Converter"))
    
    st.write(translations.get("stream_converter_description", 
             "Convert RTMP streams to HLS, DASH, or MP4 format and generate embed codes for your website."))
             
    # Create tabs for RTMP converter and RTMP source generator
    tab_names = [
        translations.get("stream_converter", "Stream Converter"),
        translations.get("rtmp_source_generator", "RTMP Source Generator")
    ]
    
    # Create the tabs
    converter_tab, generator_tab = st.tabs(tab_names)
    
    # Stream Converter Tab
    with converter_tab:
        # RTMP Input
        st.header(translations.get("rtmp_input", "RTMP Stream Input"))
        
        # Input for RTMP URL
        rtmp_url = st.text_input(
            translations.get("rtmp_url", "RTMP Stream URL"), 
            value=st.session_state.rtmp_url,
            help=translations.get("rtmp_url_help", "Enter your RTMP stream URL (e.g., rtmp://server.com/live/stream-key)")
        )
        
        # Update session state
        if rtmp_url != st.session_state.rtmp_url:
            st.session_state.rtmp_url = rtmp_url
            st.session_state.preview_path = None
            st.session_state.conversion_result = None
            st.session_state.embed_code = None
        
        # Display preview and conversion options if a URL is provided
        if rtmp_url:
            # Validate button
            validate_col, preview_col = st.columns(2)
            
            with validate_col:
                if st.button(translations.get("validate_stream", "Validate Stream")):
                    with st.spinner(translations.get("validating_stream", "Validating stream...")):
                        is_valid = validate_rtmp_stream(rtmp_url)
                        if is_valid:
                            st.success(translations.get("stream_valid", "Stream is valid and accessible!"))
                        else:
                            st.error(translations.get("stream_invalid", "Could not access the stream. Please check the URL and try again."))
            
            with preview_col:
                if st.button(translations.get("generate_preview", "Generate Preview")):
                    with st.spinner(translations.get("generating_preview", "Generating preview thumbnail...")):
                        preview_path = create_preview_thumbnail(rtmp_url)
                        if preview_path:
                            st.session_state.preview_path = preview_path
                            st.success(translations.get("preview_success", "Preview generated successfully!"))
                        else:
                            st.error(translations.get("preview_error", "Could not generate preview. Please check the stream."))
            
            # Display preview if available
            if st.session_state.preview_path and os.path.exists(st.session_state.preview_path):
                st.subheader(translations.get("stream_preview", "Stream Preview"))
                st.image(st.session_state.preview_path, use_column_width=True)
            
            # Conversion options
            st.header(translations.get("conversion_options", "Conversion Options"))
            
            conversion_type = st.radio(
                translations.get("select_format", "Select output format"),
                options=["HLS", "DASH", "MP4"],
                horizontal=True
            )
            
            # Default duration for MP4
            duration = 30
            
            if conversion_type == "MP4":
                duration = st.slider(
                    translations.get("clip_duration", "Clip duration (seconds)"),
                    min_value=10,
                    max_value=300,
                    value=30,
                    step=10
                )
            
            # Conversion button
            if st.button(translations.get("convert_stream", "Convert Stream")):
                with st.spinner(translations.get("converting_stream", f"Converting stream to {conversion_type}...")):
                    if conversion_type == "HLS":
                        result = convert_rtmp_to_hls(rtmp_url)
                    elif conversion_type == "DASH":
                        result = convert_rtmp_to_dash(rtmp_url)
                    else:  # MP4
                        result = convert_rtmp_to_mp4(rtmp_url, duration=duration)
                    
                    if result:
                        st.session_state.conversion_result = result
                        st.session_state.embed_code = generate_embed_code(result)
                        st.success(translations.get("conversion_success", f"Stream converted to {conversion_type} successfully!"))
                    else:
                        st.error(translations.get("conversion_error", "Conversion failed. Please check the stream URL and try again."))
            
            # Display embed code if available
            if st.session_state.embed_code:
                st.header(translations.get("embed_code", "Embed Code"))
                st.code(st.session_state.embed_code, language="html")
                
                # Copy button
                if st.button(translations.get("copy_embed_code", "Copy Embed Code")):
                    st.success(translations.get("code_copied", "Embed code copied to clipboard!"))
                
                # Preview the embedded player
                st.subheader(translations.get("embedded_player_preview", "Embedded Player Preview"))
                html(st.session_state.embed_code, height=400)
    
    # RTMP Source Generator Tab
    with generator_tab:
        st.header(translations.get("rtmp_source_generator", "RTMP Source Generator"))
        st.write(translations.get("rtmp_source_description", "Don't have an RTMP stream? Generate a source here to start streaming."))
        
        # SSL option
        use_ssl = st.checkbox("Use SSL for secure streaming (RTMPS)", value=False, 
                             help="Secure RTMP with SSL, which is better supported by modern browsers but requires domain verification")
        
        # Generate RTMP source button
        if st.button(translations.get("generate_rtmp_source", "Generate RTMP Source")):
            with st.spinner("Generating RTMP source..."):
                # Import the function directly to ensure it's available
                from stream_converter import generate_rtmp_source
                # Generate a new RTMP source with SSL option
                st.session_state.rtmp_source = generate_rtmp_source(use_ssl=use_ssl)
                st.success("RTMP source generated successfully!")
        
        # Display RTMP source information if available
        if st.session_state.rtmp_source:
            st.subheader(translations.get("rtmp_source_info", "Your RTMP Stream Source"))
            
            # Server URL and Stream Key
            server_url = st.session_state.rtmp_source['server_url']
            stream_key = st.session_state.rtmp_source['stream_key']
            
            # Display server URL
            server_col1, server_col2 = st.columns([4, 1])
            with server_col1:
                st.text_input(
                    translations.get("rtmp_server_url", "RTMP Server URL"),
                    value=server_url,
                    disabled=True,
                    key="server_url_input"
                )
            with server_col2:
                if st.button(translations.get("copy_to_clipboard", "Copy"), key="copy_server_url"):
                    st.success(translations.get("copied_to_clipboard", "Copied to clipboard!"))
            
            # Display stream key
            key_col1, key_col2 = st.columns([4, 1])
            with key_col1:
                st.text_input(
                    translations.get("rtmp_stream_key", "Stream Key"),
                    value=stream_key,
                    disabled=True,
                    key="stream_key_input"
                )
            with key_col2:
                if st.button(translations.get("copy_to_clipboard", "Copy"), key="copy_stream_key"):
                    st.success(translations.get("copied_to_clipboard", "Copied to clipboard!"))
            
            # Connection instructions
            st.subheader(translations.get("rtmp_connection_instructions", "Connection Instructions"))
            
            # Tabs for different streaming software
            obs_tab, wirecast_tab, vmix_tab = st.tabs([
                translations.get("connect_with_obs", "Connect with OBS Studio"),
                translations.get("connect_with_wirecast", "Connect with Wirecast"),
                translations.get("connect_with_vmix", "Connect with vMix")
            ])
            
            with obs_tab:
                # Import the function directly to ensure it's available
                from stream_converter import get_obs_instructions
                st.code(get_obs_instructions(server_url, stream_key))
            
            with wirecast_tab:
                # Import the function directly to ensure it's available
                from stream_converter import get_wirecast_instructions
                st.code(get_wirecast_instructions(server_url, stream_key))
            
            with vmix_tab:
                # Import the function directly to ensure it's available
                from stream_converter import get_vmix_instructions
                st.code(get_vmix_instructions(server_url, stream_key))
            
            # SSL verification section (if SSL is used)
            if st.session_state.rtmp_source.get('use_ssl'):
                st.subheader("SSL Domain Verification")
                st.write("To enable secure RTMPS streaming, add this TXT record to your domain's DNS settings:")
                
                # Show the TXT record for verification
                st.code(st.session_state.rtmp_source['txt_record'])
                
                verification_col1, verification_col2 = st.columns([3, 1])
                with verification_col1:
                    domain_to_verify = st.text_input(
                        "Domain to verify", 
                        value="streaming.videostream.com",
                        help="Enter the domain you'll be streaming from"
                    )
                
                with verification_col2:
                    if st.button("Verify Domain"):
                        from stream_converter import verify_ssl_domain
                        
                        # Verify the domain
                        is_verified = verify_ssl_domain(
                            domain_to_verify, 
                            st.session_state.rtmp_source['verification_code']
                        )
                        
                        if is_verified:
                            st.success(f"Domain {domain_to_verify} verified successfully! SSL is now active.")
                        else:
                            st.error(f"Could not verify domain {domain_to_verify}. Please check the TXT record and try again.")
            
            # Live Preview section
            st.subheader(translations.get("live_preview", "Live Preview"))
            
            # Show demo player for previewing
            from stream_converter import generate_demo_preview_player
            preview_html = generate_demo_preview_player(stream_key)
            
            # Display the message and preview
            st.info(translations.get("not_streaming", "Not streaming yet. Start your stream using the RTMP URL above."))
            st.components.v1.html(preview_html, height=400)
            
            # Note about the preview
            st.caption("This preview player simulates how your stream will appear once you start streaming from your broadcast software.")
            
            # Add button to use this RTMP stream in the converter tab
            if st.button("Use This RTMP Source in Converter"):
                # Create the full RTMP URL by combining server URL and stream key
                full_rtmp_url = f"{server_url}/{stream_key}"
                # Update the session state for the converter tab
                st.session_state.rtmp_url = full_rtmp_url
                # Show success message and rerun the app to switch to converter tab
                st.success("RTMP source added to converter")
                # Force refresh the app to show the converter tab with the new URL
                st.rerun()

elif st.session_state.current_page == "Donate":
    # Donate Page
    st.title(translations.get("donate", "Support VideoStream"))
    
    # Introduction text
    if st.session_state.language == "EN":
        donate_description = "Your support helps us continue to develop and improve VideoStream. We accept donations exclusively through MoMo payment platform."
    elif st.session_state.language == "VN":
        donate_description = "Sự hỗ trợ của bạn giúp chúng tôi tiếp tục phát triển và cải thiện VideoStream. Chúng tôi chỉ nhận quyên góp thông qua nền tảng thanh toán MoMo."
    else:  # Chinese
        donate_description = "您的支持帮助我们继续开发和改进VideoStream。我们只接受通过MoMo支付平台的捐赠。"
    
    st.write(donate_description)
    
    # Create two columns layout
    qr_col, info_col = st.columns([1, 1])
    
    with qr_col:
        st.subheader(translations.get("scan_qr", "Scan QR Code"))
        # Display the real MoMo QR code
        st.image("static/momo_qr_real.png", width=300)
        
        # Add a download button for the QR code
        with open("static/momo_qr_real.png", "rb") as file:
            btn = st.download_button(
                label=translations.get("download_qr", "Download QR Code"),
                data=file,
                file_name="videostream_momo_qr.png",
                mime="image/png"
            )
            
        # Add MoMo account information
        st.markdown("---")
        st.markdown("**MoMo Account:**")
        st.markdown("**PHẠM HOÀNG THÔNG**")
        st.markdown("******077")
    
    with info_col:
        st.subheader(translations.get("donation_options", "Donation Options"))
        
        # Donation amount options
        amount_options = {
            "small": {"EN": "50,000 VND (Small Support)", "VN": "50.000 VND (Hỗ trợ nhỏ)", "CN": "50,000 VND (小额支持)"},
            "medium": {"EN": "100,000 VND (Medium Support)", "VN": "100.000 VND (Hỗ trợ vừa)", "CN": "100,000 VND (中等支持)"},
            "large": {"EN": "200,000 VND (Large Support)", "VN": "200.000 VND (Hỗ trợ lớn)", "CN": "200,000 VND (大额支持)"},
            "custom": {"EN": "Custom Amount", "VN": "Số tiền tùy chọn", "CN": "自定义金额"}
        }
        
        # Create radio buttons for donation amounts
        selected_amount = st.radio(
            translations.get("select_amount", "Select Amount"),
            options=list(amount_options.keys()),
            format_func=lambda x: amount_options[x][st.session_state.language]
        )
        
        # If custom amount is selected, show a number input
        if selected_amount == "custom":
            # Always use VND since we're using MoMo
            currency_label = "VND"
            default_value = 100000
            step = 10000
                
            custom_amount = st.number_input(
                translations.get("enter_amount", "Enter Amount") + f" ({currency_label})",
                min_value=10000,
                value=default_value,
                step=step
            )
        
        # Name and message fields
        donor_name = st.text_input(translations.get("your_name", "Your Name (Optional)"))
        donor_message = st.text_area(translations.get("message", "Message (Optional)"), height=100)
        
        # Support button
        if st.button(translations.get("support_now", "Support Now"), type="primary"):
            # In a real app, this would integrate with MoMo's payment API
            # For now, we'll just show a success message
            st.success(translations.get("donation_thanks", "Thank you for your support! Please complete the payment using the MoMo app by scanning the QR code."))
            
        # Additional note about MoMo
        st.info(translations.get("momo_note", "Note: MoMo is a popular mobile payment app in Vietnam. If you don't have the app, you can download it from the App Store or Google Play Store."))

elif st.session_state.current_page == "Contact":
    # Contact Page
    st.title(translations.get("contact", "Contact"))
    st.write(translations.get("contact_description", "Get in touch with our team for any questions, feedback, or support."))
    
    # Contact form
    contact_form_col, contact_info_col = st.columns([2, 1])
    
    with contact_form_col:
        if st.session_state.contact_form_submitted:
            st.success(translations.get("contact_success", "Thank you for your message! We'll get back to you soon."))
        else:
            name = st.text_input(translations.get("contact_name", "Your Name"))
            email = st.text_input(translations.get("contact_email", "Your Email"))
            subject = st.text_input(translations.get("contact_subject", "Subject"))
            message = st.text_area(translations.get("contact_message", "Message"), height=150)
            
            if st.button(translations.get("contact_submit", "Submit")):
                # Here you would typically process the form submission
                # For now, just show a success message and set the session state
                st.session_state.contact_form_submitted = True
                st.rerun()
    
    with contact_info_col:
        st.subheader(translations.get("contact_information", "Contact Information"))
        st.write(translations.get("contact_email_address", "Email: support@videostream.com"))
        st.write(translations.get("contact_phone", "Phone: +1 (555) 123-4567"))
        st.write(translations.get("contact_address", "Address: 123 Video Street, Stream City, VS 12345"))
        st.write(translations.get("contact_hours", "Business Hours: Monday-Friday, 9:00 AM - 5:00 PM EST"))

# Dashboard section removed as requested

# Footer
st.markdown("---")
current_year = 2025
st.markdown(f"© {current_year} VideoStream - {translations.get('footer_text', 'A Streamlit-based Video Platform')}")
