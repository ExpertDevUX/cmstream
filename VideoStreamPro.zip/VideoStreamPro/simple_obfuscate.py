import os
import shutil
import base64
import zlib
import sys

def obfuscate_project():
    """Create a more secure version of the project."""
    print("Starting code protection process...")
    
    # Create secure directory
    output_dir = "secure"
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    os.makedirs(output_dir)
    
    # Files to protect
    files_to_protect = [
        'app.py',
        'data_manager.py',
        'stream_converter.py',
        'utils.py',
        'video_service.py'
    ]
    
    # Process each file
    for file_path in files_to_protect:
        if os.path.exists(file_path):
            # Read original content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Apply basic protection (compression + base64 encoding)
            compressed = zlib.compress(content.encode('utf-8'))
            encoded = base64.b64encode(compressed).decode('utf-8')
            
            # Create protected version
            module_name = os.path.splitext(os.path.basename(file_path))[0]
            protected_content = f"""# This file is protected - VideoStream CMS
# Copyright (c) 2023-2025 - All Rights Reserved
# Proprietary and Confidential
# Unauthorized copying, modification or distribution is strictly prohibited

import base64
import zlib
import sys
import os
import types
import builtins

# Protected content (encoded)
_protected_data = "{encoded}"

# Decode and execute
_decoded = base64.b64decode(_protected_data)
_decompressed = zlib.decompress(_decoded)

# Security measures
_original_open = builtins.open
def _restricted_open(file, mode='r', *args, **kwargs):
    if file == __file__ and 'r' in mode:
        raise PermissionError("Security violation: Source access denied")
    return _original_open(file, mode, *args, **kwargs)
builtins.open = _restricted_open

# Execute protected code
_module = types.ModuleType('{module_name}')
sys.modules['{module_name}'] = _module
# Set __file__ variable which is needed by some functions
_module.__dict__['__file__'] = __file__
exec(_decompressed, _module.__dict__)
"""
            
            # Save protected file
            output_path = os.path.join(output_dir, os.path.basename(file_path))
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(protected_content)
            print(f"Protected: {file_path}")
    
    # Copy static files and directories
    for item in ['static']:
        if os.path.exists(item):
            if os.path.isdir(item):
                dest = os.path.join(output_dir, item)
                if os.path.exists(dest):
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, os.path.join(output_dir, item))
            print(f"Copied: {item}")
    
    # Create launcher script
    launcher = """#!/usr/bin/env python
# VideoStream Secure Launcher
# Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved

import os
import sys
import streamlit.web.cli as stcli

print("="*60)
print("VideoStream CMS - Secure Edition")
print("Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved")
print("Starting secure application...")
print("="*60)

# Anti-inspection measures
import builtins
_original_open = builtins.open
def _restricted_open(file, mode='r', *args, **kwargs):
    # Prevent reading source files
    if any(file.endswith(ext) for ext in ['.py']) and 'r' in mode:
        # Allow certain files to be read
        if not any(os.path.basename(file) == f for f in ['start.py']):
            raise PermissionError(f"Security violation: Source access denied for {file}")
    return _original_open(file, mode, *args, **kwargs)
builtins.open = _restricted_open

# Run the application
sys.argv = ["streamlit", "run", "app.py", "--server.port=5000", 
            "--server.headless=true", "--server.address=0.0.0.0"]
sys.exit(stcli.main())
"""
    
    with open(os.path.join(output_dir, "start.py"), 'w') as f:
        f.write(launcher)
    print("Created launcher script")
    
    # Create README
    readme = """# VideoStream CMS - Secure Edition

This is the secured version of VideoStream CMS.

## Running the Application

To run the secured application:

```
cd secure
python start.py
```

## Security Notice

The code in this directory is protected by security measures.
Attempting to view, modify, or reverse-engineer the code is prohibited.

Copyright (c) 2023-2025 VideoStream CMS - All Rights Reserved
"""
    
    with open(os.path.join(output_dir, "README.md"), 'w') as f:
        f.write(readme)
    print("Created README file")
    
    print("\nProtection process completed successfully!")
    print(f"The secured application is available in the '{output_dir}' directory")
    print("To run the secured app, use: cd secure && python start.py")

if __name__ == "__main__":
    obfuscate_project()