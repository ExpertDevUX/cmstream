import os
import sys
import streamlit.web.cli as stcli
from license_check import check_license

def run_app():
    """
    Run the VideoStream application with license validation.
    This function checks if the user has a valid license before launching the application.
    """
    # Verify license
    if not check_license():
        print("License verification failed. Application will exit.")
        sys.exit(1)
    
    print("License verified successfully. Starting VideoStream application...")
    
    # Launch Streamlit app
    sys.argv = ["streamlit", "run", "app.py", "--server.port=5000", "--server.headless=true", "--server.address=0.0.0.0"]
    sys.exit(stcli.main())

if __name__ == "__main__":
    run_app()