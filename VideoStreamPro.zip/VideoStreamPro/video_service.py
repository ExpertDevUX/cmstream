import requests
import os
import pandas as pd
import json
from pytube import YouTube, Search
import streamlit as st

# Cache the video data to avoid repeated API calls
@st.cache_data(ttl=3600)  # Cache for 1 hour
def fetch_trending_videos(limit=12):
    """
    Fetch trending videos using PyTube
    
    Args:
        limit (int): Maximum number of videos to return
        
    Returns:
        list: List of video dictionaries with metadata
    """
    try:
        # This is a workaround since PyTube doesn't have a direct trending videos API
        # We'll search for popular topics and combine results
        popular_topics = ["music", "news", "gaming", "tech", "sports"]
        all_videos = []
        
        for topic in popular_topics:
            s = Search(topic)
            results = s.results
            
            # Convert to our standard format
            for video in results[:3]:  # Get top 3 from each topic
                try:
                    all_videos.append({
                        'id': video.video_id,
                        'title': video.title,
                        'description': video.description[:150] + "..." if video.description else "No description available",
                        'thumbnail': f"https://img.youtube.com/vi/{video.video_id}/mqdefault.jpg",
                        'channel': video.author,
                        'views': "N/A",  # Would need additional API call to get this
                        'likes': "N/A",  # Would need additional API call to get this
                        'published_at': "N/A",  # Would need additional API call to get this
                        'category': topic.capitalize()
                    })
                except Exception as e:
                    print(f"Error processing video: {e}")
                    continue
        
        # Return unique videos up to the limit
        seen_ids = set()
        unique_videos = []
        
        for video in all_videos:
            if video['id'] not in seen_ids and len(unique_videos) < limit:
                seen_ids.add(video['id'])
                unique_videos.append(video)
        
        return unique_videos
    
    except Exception as e:
        print(f"Error fetching trending videos: {e}")
        return []

@st.cache_data(ttl=3600)  # Cache for 1 hour
def fetch_videos_by_category(category, exclude_id=None, limit=12):
    """
    Fetch videos by category using PyTube
    
    Args:
        category (str): Category to fetch videos for
        exclude_id (str, optional): Video ID to exclude from results
        limit (int): Maximum number of videos to return
        
    Returns:
        list: List of video dictionaries with metadata
    """
    try:
        # Search for videos in the category
        s = Search(category)
        results = s.results
        
        # Convert to our standard format
        videos = []
        for video in results:
            try:
                # Skip the excluded video if specified
                if exclude_id and video.video_id == exclude_id:
                    continue
                
                videos.append({
                    'id': video.video_id,
                    'title': video.title,
                    'description': video.description[:150] + "..." if video.description else "No description available",
                    'thumbnail': f"https://img.youtube.com/vi/{video.video_id}/mqdefault.jpg",
                    'channel': video.author,
                    'views': "N/A",
                    'likes': "N/A",
                    'published_at': "N/A",
                    'category': category
                })
                
                if len(videos) >= limit:
                    break
            except Exception as e:
                print(f"Error processing video: {e}")
                continue
        
        return videos
    
    except Exception as e:
        print(f"Error fetching videos by category: {e}")
        return []

@st.cache_data(ttl=3600)  # Cache for 1 hour
def search_videos(query, limit=12):
    """
    Search for videos using PyTube
    
    Args:
        query (str): Search query
        limit (int): Maximum number of videos to return
        
    Returns:
        list: List of video dictionaries with metadata
    """
    try:
        # Search for videos
        s = Search(query)
        results = s.results
        
        # Convert to our standard format
        videos = []
        for video in results:
            try:
                videos.append({
                    'id': video.video_id,
                    'title': video.title,
                    'description': video.description[:150] + "..." if video.description else "No description available",
                    'thumbnail': f"https://img.youtube.com/vi/{video.video_id}/mqdefault.jpg",
                    'channel': video.author,
                    'views': "N/A",
                    'likes': "N/A",
                    'published_at': "N/A",
                    'category': "Search Result"
                })
                
                if len(videos) >= limit:
                    break
            except Exception as e:
                print(f"Error processing video: {e}")
                continue
        
        return videos
    
    except Exception as e:
        print(f"Error searching videos: {e}")
        return []

@st.cache_data(ttl=1800)  # Cache for 30 minutes
def fetch_video_details(video_id):
    """
    Fetch detailed information about a specific video
    
    Args:
        video_id (str): YouTube video ID
        
    Returns:
        dict: Video details including title, description, views, likes, etc.
    """
    try:
        # Fetch video details using PyTube
        yt = YouTube(f"https://www.youtube.com/watch?v={video_id}")
        
        # Format views and likes for display
        views = f"{yt.views:,}" if hasattr(yt, 'views') else "N/A"
        
        # PyTube doesn't provide likes directly, we'd need to use YouTube Data API for this
        # For now, we'll use a placeholder
        likes = "N/A"
        
        # Get the publish date
        published_at = yt.publish_date.strftime("%B %d, %Y") if hasattr(yt, 'publish_date') and yt.publish_date else "N/A"
        
        # Get video category
        # PyTube doesn't provide category directly, we'll use the author/channel as a proxy
        category = yt.author if hasattr(yt, 'author') else "Unknown"
        
        return {
            'id': video_id,
            'title': yt.title,
            'description': yt.description or "No description available",
            'thumbnail': f"https://img.youtube.com/vi/{video_id}/mqdefault.jpg",
            'channel': yt.author,
            'views': views,
            'likes': likes,
            'published_at': published_at,
            'category': category
        }
    
    except Exception as e:
        print(f"Error fetching video details: {e}")
        return None
