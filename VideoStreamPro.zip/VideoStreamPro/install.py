#!/usr/bin/env python3
"""
VideoStream CMS - Installation Script
====================================
This script automates the installation of VideoStream CMS on a server.
It handles dependencies, directory creation, permissions, and configuration.
"""

import os
import sys
import shutil
import subprocess
import platform
import re
import socket
import time
import getpass
from pathlib import Path
import argparse
import json
import urllib.request
import ssl
import dns.resolver
import random
import string

# Setup colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# Configuration options
DEFAULT_CONFIG = {
    'server_dir': '/var/www/videostream',
    'hls_dir': '/var/www/videostream/hls',
    'dash_dir': '/var/www/videostream/dash',
    'mp4_dir': '/var/www/videostream/mp4',
    'thumbnails_dir': '/var/www/videostream/thumbnails',
    'ssl_enabled': False,
    'domain': '',
    'use_nginx': True,
    'port': 5000,
    'ssl_cert_path': '',
    'ssl_key_path': '',
    'auto_start': True,
    'install_service': True,
    'setup_permissions': True,
}

def print_banner():
    """Print installation banner"""
    banner = f"""
{Colors.BLUE}╔══════════════════════════════════════════════════════════╗
║                                                          ║
║      {Colors.BOLD}VideoStream CMS - Installation Script{Colors.ENDC}{Colors.BLUE}             ║
║                                                          ║
║  This script will install and configure VideoStream CMS  ║
║  on your server with all required dependencies.          ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝{Colors.ENDC}
"""
    print(banner)

def check_dependencies():
    """Check for required dependencies and install them if needed"""
    print(f"{Colors.HEADER}Checking system dependencies...{Colors.ENDC}")
    
    dependencies = {
        'apt': ['python3', 'python3-pip', 'python3-venv', 'ffmpeg', 'nginx'],
        'yum': ['python3', 'python3-pip', 'ffmpeg', 'nginx'],
        'dnf': ['python3', 'python3-pip', 'ffmpeg', 'nginx'],
        'pacman': ['python', 'python-pip', 'ffmpeg', 'nginx']
    }
    
    # Detect package manager
    package_manager = None
    if os.path.exists('/usr/bin/apt') or os.path.exists('/bin/apt'):
        package_manager = 'apt'
    elif os.path.exists('/usr/bin/yum') or os.path.exists('/bin/yum'):
        package_manager = 'yum'
    elif os.path.exists('/usr/bin/dnf') or os.path.exists('/bin/dnf'):
        package_manager = 'dnf'
    elif os.path.exists('/usr/bin/pacman') or os.path.exists('/bin/pacman'):
        package_manager = 'pacman'
    
    if not package_manager:
        print(f"{Colors.WARNING}Could not detect package manager. You may need to install dependencies manually.{Colors.ENDC}")
        return False
    
    # Install dependencies
    for dep in dependencies[package_manager]:
        print(f"Checking for {dep}...")
        
        # Different check command based on package manager
        if package_manager == 'apt':
            check_cmd = ['dpkg', '-l', dep]
        elif package_manager in ['yum', 'dnf']:
            check_cmd = ['rpm', '-q', dep]
        elif package_manager == 'pacman':
            check_cmd = ['pacman', '-Qi', dep]
        
        try:
            result = subprocess.run(check_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if result.returncode != 0:
                print(f"{Colors.WARNING}Installing {dep}...{Colors.ENDC}")
                
                # Different install command based on package manager
                if package_manager == 'apt':
                    install_cmd = ['apt-get', 'install', '-y', dep]
                elif package_manager == 'yum':
                    install_cmd = ['yum', 'install', '-y', dep]
                elif package_manager == 'dnf':
                    install_cmd = ['dnf', 'install', '-y', dep]
                elif package_manager == 'pacman':
                    install_cmd = ['pacman', '-S', '--noconfirm', dep]
                
                try:
                    subprocess.run(install_cmd, check=True)
                    print(f"{Colors.GREEN}Successfully installed {dep}{Colors.ENDC}")
                except subprocess.CalledProcessError:
                    print(f"{Colors.FAIL}Failed to install {dep}. Please install it manually.{Colors.ENDC}")
                    return False
            else:
                print(f"{Colors.GREEN}✓ {dep} is already installed{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.FAIL}Error checking for {dep}: {str(e)}{Colors.ENDC}")
            return False
    
    return True

def create_directories(config):
    """Create required directories for the application"""
    print(f"\n{Colors.HEADER}Creating application directories...{Colors.ENDC}")
    
    directories = [
        config['server_dir'],
        config['hls_dir'],
        config['dash_dir'],
        config['mp4_dir'],
        config['thumbnails_dir']
    ]
    
    for directory in directories:
        try:
            if not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)
                print(f"{Colors.GREEN}Created directory: {directory}{Colors.ENDC}")
            else:
                print(f"{Colors.GREEN}✓ Directory already exists: {directory}{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.FAIL}Failed to create directory {directory}: {str(e)}{Colors.ENDC}")
            return False
    
    return True

def set_permissions(config):
    """Set appropriate permissions for directories"""
    if not config['setup_permissions']:
        print(f"\n{Colors.WARNING}Skipping permission setup as per configuration.{Colors.ENDC}")
        return True
    
    print(f"\n{Colors.HEADER}Setting directory permissions...{Colors.ENDC}")
    
    # Get web server user
    web_user = 'www-data'  # Default for Debian/Ubuntu
    
    # Try to detect web server user based on OS
    if os.path.exists('/etc/redhat-release'):
        web_user = 'apache'  # CentOS/RHEL/Fedora
    
    directories = [
        config['server_dir'],
        config['hls_dir'],
        config['dash_dir'],
        config['mp4_dir'],
        config['thumbnails_dir']
    ]
    
    for directory in directories:
        try:
            # Use current user and web server group
            current_user = getpass.getuser()
            
            # Change ownership
            chown_cmd = ['chown', '-R', f"{current_user}:{web_user}", directory]
            subprocess.run(chown_cmd, check=True)
            
            # Set permissions (755 for directories, 644 for files)
            chmod_dirs_cmd = ['find', directory, '-type', 'd', '-exec', 'chmod', '755', '{}', ';']
            chmod_files_cmd = ['find', directory, '-type', 'f', '-exec', 'chmod', '644', '{}', ';']
            
            subprocess.run(chmod_dirs_cmd, check=True)
            subprocess.run(chmod_files_cmd, check=True)
            
            print(f"{Colors.GREEN}Set permissions for {directory}{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.WARNING}Could not set permissions for {directory}: {str(e)}{Colors.ENDC}")
            print(f"{Colors.WARNING}You may need to set permissions manually.{Colors.ENDC}")
    
    return True

def setup_python_environment(config):
    """Setup Python virtual environment and install requirements"""
    print(f"\n{Colors.HEADER}Setting up Python environment...{Colors.ENDC}")
    
    venv_dir = os.path.join(config['server_dir'], 'venv')
    
    try:
        # Create virtual environment
        if not os.path.exists(venv_dir):
            print(f"Creating virtual environment in {venv_dir}...")
            subprocess.run([sys.executable, '-m', 'venv', venv_dir], check=True)
        else:
            print(f"{Colors.GREEN}✓ Virtual environment already exists{Colors.ENDC}")
        
        # Install required Python packages
        pip_path = os.path.join(venv_dir, 'bin', 'pip')
        
        requirements = [
            'streamlit',
            'deep-translator',
            'ffmpeg-python',
            'googletrans-py',
            'm3u8',
            'pandas',
            'requests',
            'streamlink',
            'streamlit-option-menu',
            'streamlit-player',
            'dnspython'
        ]
        
        print("Installing Python packages...")
        for req in requirements:
            try:
                subprocess.run([pip_path, 'install', req], check=True)
                print(f"{Colors.GREEN}✓ Installed {req}{Colors.ENDC}")
            except subprocess.CalledProcessError:
                print(f"{Colors.FAIL}Failed to install {req}. Please install it manually.{Colors.ENDC}")
        
        return True
    except Exception as e:
        print(f"{Colors.FAIL}Error setting up Python environment: {str(e)}{Colors.ENDC}")
        return False

def copy_application_files(config):
    """Copy application files to server directory"""
    print(f"\n{Colors.HEADER}Installing application files...{Colors.ENDC}")
    
    # Current directory (where this script is running)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Files and directories to copy
    items_to_copy = [
        'app.py',
        'data_manager.py',
        'stream_converter.py',
        'utils.py',
        'video_service.py',
        'static'
    ]
    
    for item in items_to_copy:
        source = os.path.join(current_dir, item)
        destination = os.path.join(config['server_dir'], item)
        
        try:
            if os.path.isdir(source):
                if os.path.exists(destination):
                    shutil.rmtree(destination)
                shutil.copytree(source, destination)
                print(f"{Colors.GREEN}Copied directory: {item}{Colors.ENDC}")
            else:
                shutil.copy2(source, destination)
                print(f"{Colors.GREEN}Copied file: {item}{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.FAIL}Failed to copy {item}: {str(e)}{Colors.ENDC}")
            return False
    
    return True

def generate_ssl_verification_code():
    """Generate a random verification code for SSL/DNS verification"""
    letters = string.ascii_letters + string.digits
    return 'videostreamcms-verify-' + ''.join(random.choice(letters) for i in range(16))

def verify_domain_dns(domain, verification_code):
    """Verify domain ownership through DNS TXT records"""
    print(f"\n{Colors.HEADER}Verifying domain ownership through DNS TXT records...{Colors.ENDC}")
    print(f"Please add the following TXT record to your domain's DNS settings:")
    print(f"\n{Colors.BOLD}Record Type:{Colors.ENDC} TXT")
    print(f"{Colors.BOLD}Host/Name:{Colors.ENDC} _videostream-verify.{domain}")
    print(f"{Colors.BOLD}Value/Content:{Colors.ENDC} {verification_code}")
    print(f"\nThis TXT record proves you control the domain {domain}.")
    
    verify = input(f"\n{Colors.WARNING}Have you added the TXT record? (Type 'verify' to check, or 'skip' to skip DNS verification): {Colors.ENDC}")
    
    if verify.lower() == 'skip':
        print(f"{Colors.WARNING}DNS verification skipped. SSL will not be fully configured.{Colors.ENDC}")
        return False
    
    if verify.lower() != 'verify':
        print(f"{Colors.WARNING}Invalid input. Please type 'verify' to check, or 'skip' to skip.{Colors.ENDC}")
        return verify_domain_dns(domain, verification_code)
    
    # Check for DNS TXT record
    try:
        print(f"Checking DNS records for _videostream-verify.{domain}...")
        time.sleep(2)  # Give time for DNS propagation
        
        # Try up to 3 times with delays
        for attempt in range(3):
            try:
                resolver = dns.resolver.Resolver()
                resolver.timeout = 5
                resolver.lifetime = 10
                
                answers = resolver.resolve(f"_videostream-verify.{domain}", 'TXT')
                
                for rdata in answers:
                    for txt_string in rdata.strings:
                        txt_value = txt_string.decode('utf-8')
                        if txt_value == verification_code:
                            print(f"{Colors.GREEN}DNS verification successful! Domain ownership confirmed.{Colors.ENDC}")
                            return True
                
                print(f"{Colors.WARNING}Verification code not found in DNS records.{Colors.ENDC}")
                
                if attempt < 2:
                    wait_time = (attempt + 1) * 30
                    print(f"DNS changes may take time to propagate. Waiting {wait_time} seconds before trying again...")
                    time.sleep(wait_time)
            except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
                print(f"{Colors.WARNING}TXT record not found. DNS changes may take time to propagate.{Colors.ENDC}")
                
                if attempt < 2:
                    wait_time = (attempt + 1) * 30
                    print(f"Waiting {wait_time} seconds before trying again...")
                    time.sleep(wait_time)
            except Exception as e:
                print(f"{Colors.FAIL}Error checking DNS records: {str(e)}{Colors.ENDC}")
                
                if attempt < 2:
                    wait_time = (attempt + 1) * 30
                    print(f"Waiting {wait_time} seconds before trying again...")
                    time.sleep(wait_time)
        
        print(f"{Colors.WARNING}Could not verify domain ownership through DNS.{Colors.ENDC}")
        retry = input(f"Would you like to try again? (yes/no): ")
        
        if retry.lower() == 'yes':
            return verify_domain_dns(domain, verification_code)
        else:
            print(f"{Colors.WARNING}DNS verification skipped. SSL will not be fully configured.{Colors.ENDC}")
            return False
    except Exception as e:
        print(f"{Colors.FAIL}Error during DNS verification: {str(e)}{Colors.ENDC}")
        return False

def setup_ssl(config):
    """Setup SSL for the domain if enabled"""
    if not config['ssl_enabled']:
        print(f"\n{Colors.WARNING}SSL is disabled in configuration. Skipping SSL setup.{Colors.ENDC}")
        return True
    
    if not config['domain']:
        print(f"{Colors.FAIL}SSL is enabled but no domain is specified in configuration.{Colors.ENDC}")
        return False
    
    print(f"\n{Colors.HEADER}Setting up SSL for {config['domain']}...{Colors.ENDC}")
    
    # Generate verification code for domain ownership
    verification_code = generate_ssl_verification_code()
    
    # Verify domain ownership through DNS
    if not verify_domain_dns(config['domain'], verification_code):
        print(f"{Colors.WARNING}Proceeding without complete SSL verification.{Colors.ENDC}")
    
    # Check if certbot is installed
    try:
        subprocess.run(['certbot', '--version'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        print(f"{Colors.GREEN}✓ Certbot is installed{Colors.ENDC}")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print(f"{Colors.WARNING}Certbot not found. Installing Certbot...{Colors.ENDC}")
        
        # Install certbot based on package manager
        if os.path.exists('/usr/bin/apt') or os.path.exists('/bin/apt'):
            try:
                subprocess.run(['apt-get', 'update'], check=True)
                subprocess.run(['apt-get', 'install', '-y', 'certbot', 'python3-certbot-nginx'], check=True)
            except subprocess.CalledProcessError:
                print(f"{Colors.FAIL}Failed to install Certbot. Please install it manually.{Colors.ENDC}")
                return False
        elif os.path.exists('/usr/bin/yum') or os.path.exists('/bin/yum'):
            try:
                subprocess.run(['yum', 'install', '-y', 'certbot', 'python3-certbot-nginx'], check=True)
            except subprocess.CalledProcessError:
                print(f"{Colors.FAIL}Failed to install Certbot. Please install it manually.{Colors.ENDC}")
                return False
        elif os.path.exists('/usr/bin/dnf') or os.path.exists('/bin/dnf'):
            try:
                subprocess.run(['dnf', 'install', '-y', 'certbot', 'python3-certbot-nginx'], check=True)
            except subprocess.CalledProcessError:
                print(f"{Colors.FAIL}Failed to install Certbot. Please install it manually.{Colors.ENDC}")
                return False
        else:
            print(f"{Colors.FAIL}Could not install Certbot. Please install it manually.{Colors.ENDC}")
            return False
    
    # Generate SSL certificate with certbot
    try:
        print(f"Generating SSL certificate for {config['domain']}...")
        
        if config['use_nginx']:
            # Use certbot with nginx plugin
            certbot_cmd = [
                'certbot', 'certonly', '--nginx',
                '-d', config['domain'], '-d', f"www.{config['domain']}",
                '--agree-tos', '--non-interactive',
                '--email', 'admin@' + config['domain']
            ]
        else:
            # Use certbot standalone
            certbot_cmd = [
                'certbot', 'certonly', '--standalone',
                '-d', config['domain'], '-d', f"www.{config['domain']}",
                '--agree-tos', '--non-interactive',
                '--email', 'admin@' + config['domain']
            ]
        
        subprocess.run(certbot_cmd, check=True)
        
        # Set certificate paths
        config['ssl_cert_path'] = f"/etc/letsencrypt/live/{config['domain']}/fullchain.pem"
        config['ssl_key_path'] = f"/etc/letsencrypt/live/{config['domain']}/privkey.pem"
        
        print(f"{Colors.GREEN}SSL certificate generated successfully!{Colors.ENDC}")
        print(f"Certificate path: {config['ssl_cert_path']}")
        print(f"Key path: {config['ssl_key_path']}")
        
        # Setup automatic renewal
        print("Setting up automatic certificate renewal...")
        
        # Add cron job for certificate renewal
        cron_job = "0 3 * * * certbot renew --quiet --post-hook 'systemctl restart nginx'"
        cron_file = "/tmp/certbot-cron"
        
        with open(cron_file, 'w') as f:
            f.write(cron_job + "\n")
        
        try:
            subprocess.run(['crontab', '-l'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
            # Append to existing crontab
            subprocess.run('(crontab -l; cat ' + cron_file + ') | crontab -', shell=True, check=True)
        except subprocess.CalledProcessError:
            # No existing crontab
            subprocess.run(['crontab', cron_file], check=True)
        
        os.remove(cron_file)
        
        print(f"{Colors.GREEN}Automatic certificate renewal configured.{Colors.ENDC}")
        
        return True
    except Exception as e:
        print(f"{Colors.FAIL}Error generating SSL certificate: {str(e)}{Colors.ENDC}")
        print(f"{Colors.WARNING}Proceeding without SSL. You can configure SSL manually later.{Colors.ENDC}")
        
        config['ssl_enabled'] = False
        return True

def configure_nginx(config):
    """Configure Nginx to serve the application"""
    if not config['use_nginx']:
        print(f"\n{Colors.WARNING}Nginx configuration is disabled in settings. Skipping.{Colors.ENDC}")
        return True
    
    print(f"\n{Colors.HEADER}Configuring Nginx...{Colors.ENDC}")
    
    try:
        # Create Nginx configuration
        app_name = "videostream"
        domain = config['domain'] if config['domain'] else "localhost"
        
        nginx_conf = f"""
server {{
    listen 80;
    server_name {domain} www.{domain};
    
    access_log /var/log/nginx/{app_name}.access.log;
    error_log /var/log/nginx/{app_name}.error.log;
    
    # Redirect to HTTPS if SSL is enabled
    {'location / { return 301 https://$host$request_uri; }' if config['ssl_enabled'] else ''}
    
    {'# Non-SSL configuration' if config['ssl_enabled'] else 'location / {'}
    {'# End of non-SSL block' if config['ssl_enabled'] else f'''
        proxy_pass http://127.0.0.1:{config["port"]};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }}'''}
    
    # Serve media directories directly
    location /hls/ {{
        alias {config['hls_dir']}/;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
        types {{
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }}
    }}
    
    location /dash/ {{
        alias {config['dash_dir']}/;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
        types {{
            application/dash+xml mpd;
        }}
    }}
    
    location /mp4/ {{
        alias {config['mp4_dir']}/;
        add_header Cache-Control max-age=86400;
        add_header Access-Control-Allow-Origin *;
    }}
    
    location /thumbnails/ {{
        alias {config['thumbnails_dir']}/;
        add_header Cache-Control max-age=86400;
        add_header Access-Control-Allow-Origin *;
    }}
}}
"""

        # Add SSL configuration if enabled
        if config['ssl_enabled'] and os.path.exists(config['ssl_cert_path']) and os.path.exists(config['ssl_key_path']):
            nginx_ssl_conf = f"""
server {{
    listen 443 ssl http2;
    server_name {domain} www.{domain};
    
    access_log /var/log/nginx/{app_name}.access.log;
    error_log /var/log/nginx/{app_name}.error.log;
    
    ssl_certificate {config['ssl_cert_path']};
    ssl_certificate_key {config['ssl_key_path']};
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:10m;
    ssl_session_tickets off;
    ssl_stapling on;
    ssl_stapling_verify on;
    
    # HSTS (optional)
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    location / {{
        proxy_pass http://127.0.0.1:{config["port"]};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # WebSocket support
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }}
    
    # Serve media directories directly
    location /hls/ {{
        alias {config['hls_dir']}/;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
        types {{
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }}
    }}
    
    location /dash/ {{
        alias {config['dash_dir']}/;
        add_header Cache-Control no-cache;
        add_header Access-Control-Allow-Origin *;
        types {{
            application/dash+xml mpd;
        }}
    }}
    
    location /mp4/ {{
        alias {config['mp4_dir']}/;
        add_header Cache-Control max-age=86400;
        add_header Access-Control-Allow-Origin *;
    }}
    
    location /thumbnails/ {{
        alias {config['thumbnails_dir']}/;
        add_header Cache-Control max-age=86400;
        add_header Access-Control-Allow-Origin *;
    }}
}}
"""
            nginx_conf += nginx_ssl_conf
        
        # Write configuration to file
        conf_path = f"/etc/nginx/sites-available/{app_name}"
        with open(conf_path, 'w') as f:
            f.write(nginx_conf)
        
        # Create symlink to sites-enabled if it doesn't exist
        enabled_path = f"/etc/nginx/sites-enabled/{app_name}"
        if not os.path.exists(enabled_path):
            os.symlink(conf_path, enabled_path)
        
        # Test Nginx configuration
        subprocess.run(['nginx', '-t'], check=True)
        
        # Restart Nginx
        subprocess.run(['systemctl', 'restart', 'nginx'], check=True)
        
        print(f"{Colors.GREEN}Nginx configured successfully!{Colors.ENDC}")
        return True
    except Exception as e:
        print(f"{Colors.FAIL}Error configuring Nginx: {str(e)}{Colors.ENDC}")
        print(f"{Colors.WARNING}You may need to configure Nginx manually.{Colors.ENDC}")
        return False

def create_systemd_service(config):
    """Create a systemd service to run the application"""
    if not config['install_service']:
        print(f"\n{Colors.WARNING}Service installation is disabled in settings. Skipping.{Colors.ENDC}")
        return True
    
    print(f"\n{Colors.HEADER}Creating systemd service...{Colors.ENDC}")
    
    service_name = "videostream"
    
    # Create service file
    service_content = f"""[Unit]
Description=VideoStream CMS
After=network.target

[Service]
User={getpass.getuser()}
WorkingDirectory={config['server_dir']}
ExecStart={os.path.join(config['server_dir'], 'venv/bin/python')} -m streamlit run app.py --server.port={config['port']} --server.address=0.0.0.0 --server.headless=true
Restart=on-failure
RestartSec=5
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier={service_name}

[Install]
WantedBy=multi-user.target
"""
    
    try:
        # Write service file
        service_path = f"/etc/systemd/system/{service_name}.service"
        with open(service_path, 'w') as f:
            f.write(service_content)
        
        # Reload systemd
        subprocess.run(['systemctl', 'daemon-reload'], check=True)
        
        # Enable service to start on boot
        subprocess.run(['systemctl', 'enable', service_name], check=True)
        
        # Start service if configured
        if config['auto_start']:
            print(f"Starting {service_name} service...")
            subprocess.run(['systemctl', 'start', service_name], check=True)
            
            # Check if service is running
            status = subprocess.run(['systemctl', 'is-active', service_name], stdout=subprocess.PIPE, text=True)
            if status.stdout.strip() == 'active':
                print(f"{Colors.GREEN}Service {service_name} is running!{Colors.ENDC}")
            else:
                print(f"{Colors.WARNING}Service {service_name} may not be running. Check with 'systemctl status {service_name}'.{Colors.ENDC}")
        
        print(f"{Colors.GREEN}Systemd service created successfully!{Colors.ENDC}")
        print(f"You can manage the service with these commands:")
        print(f"  Start:   sudo systemctl start {service_name}")
        print(f"  Stop:    sudo systemctl stop {service_name}")
        print(f"  Restart: sudo systemctl restart {service_name}")
        print(f"  Status:  sudo systemctl status {service_name}")
        print(f"  Logs:    sudo journalctl -u {service_name}")
        
        return True
    except Exception as e:
        print(f"{Colors.FAIL}Error creating systemd service: {str(e)}{Colors.ENDC}")
        print(f"{Colors.WARNING}You may need to create the service manually.{Colors.ENDC}")
        return False

def save_config(config):
    """Save configuration to file"""
    config_path = os.path.join(config['server_dir'], 'videostream_config.json')
    
    try:
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=4)
        
        print(f"{Colors.GREEN}Configuration saved to {config_path}{Colors.ENDC}")
        return True
    except Exception as e:
        print(f"{Colors.FAIL}Error saving configuration: {str(e)}{Colors.ENDC}")
        return False

def interactive_configuration():
    """Get configuration through interactive prompts"""
    config = DEFAULT_CONFIG.copy()
    
    print(f"\n{Colors.HEADER}VideoStream CMS Configuration{Colors.ENDC}")
    print("Please answer the following questions to configure your installation.")
    print("Press Enter to accept the default values shown in brackets.\n")
    
    # Server directory
    server_dir = input(f"Installation directory [{config['server_dir']}]: ")
    if server_dir:
        config['server_dir'] = server_dir
    
    # Create other directories based on server_dir
    config['hls_dir'] = os.path.join(config['server_dir'], 'hls')
    config['dash_dir'] = os.path.join(config['server_dir'], 'dash')
    config['mp4_dir'] = os.path.join(config['server_dir'], 'mp4')
    config['thumbnails_dir'] = os.path.join(config['server_dir'], 'thumbnails')
    
    # Port
    port_str = input(f"Application port [{config['port']}]: ")
    if port_str and port_str.isdigit():
        config['port'] = int(port_str)
    
    # Domain and SSL
    domain = input("Domain name (leave empty for localhost): ")
    if domain:
        config['domain'] = domain
        
        ssl_enabled = input("Enable SSL/HTTPS? (y/n) [y]: ")
        config['ssl_enabled'] = ssl_enabled.lower() not in ['n', 'no']
    else:
        config['ssl_enabled'] = False
    
    # Nginx
    nginx = input("Configure Nginx? (y/n) [y]: ")
    config['use_nginx'] = nginx.lower() not in ['n', 'no']
    
    # Auto-start
    auto_start = input("Start application automatically after installation? (y/n) [y]: ")
    config['auto_start'] = auto_start.lower() not in ['n', 'no']
    
    # Install service
    install_service = input("Create systemd service for automatic startup? (y/n) [y]: ")
    config['install_service'] = install_service.lower() not in ['n', 'no']
    
    # Setup permissions
    setup_permissions = input("Setup directory permissions? (y/n) [y]: ")
    config['setup_permissions'] = setup_permissions.lower() not in ['n', 'no']
    
    return config

def run_installation(config):
    """Run the installation process with the provided configuration"""
    print_banner()
    
    # Installation steps
    steps = [
        ("Checking dependencies", check_dependencies),
        ("Creating directories", lambda: create_directories(config)),
        ("Setting permissions", lambda: set_permissions(config)),
        ("Setting up Python environment", lambda: setup_python_environment(config)),
        ("Copying application files", lambda: copy_application_files(config)),
        ("Setting up SSL", lambda: setup_ssl(config)),
        ("Configuring Nginx", lambda: configure_nginx(config)),
        ("Creating systemd service", lambda: create_systemd_service(config)),
        ("Saving configuration", lambda: save_config(config))
    ]
    
    # Execute each step
    step_count = len(steps)
    for i, (step_name, step_func) in enumerate(steps, 1):
        print(f"\n{Colors.BLUE}[Step {i}/{step_count}] {step_name}{Colors.ENDC}")
        
        if not step_func():
            print(f"{Colors.WARNING}Warning: Step '{step_name}' may not have completed successfully.{Colors.ENDC}")
            
            if step_name == "Checking dependencies":
                print(f"{Colors.FAIL}Cannot continue without required dependencies.{Colors.ENDC}")
                return False
            
            continue_installation = input(f"Continue with installation? (y/n) [y]: ")
            if continue_installation.lower() in ['n', 'no']:
                print(f"{Colors.FAIL}Installation aborted.{Colors.ENDC}")
                return False
    
    # Installation complete
    print(f"\n{Colors.GREEN}{Colors.BOLD}Installation Complete!{Colors.ENDC}")
    
    # Show access information
    if config['domain']:
        if config['ssl_enabled']:
            print(f"\nYou can access VideoStream CMS at: https://{config['domain']}")
        else:
            print(f"\nYou can access VideoStream CMS at: http://{config['domain']}")
    else:
        print(f"\nYou can access VideoStream CMS at: http://your-server-ip:{config['port']}")
    
    print(f"\n{Colors.BOLD}Installation Details:{Colors.ENDC}")
    print(f"  - Application directory: {config['server_dir']}")
    print(f"  - Media directories:")
    print(f"    - HLS streams:  {config['hls_dir']}")
    print(f"    - DASH streams: {config['dash_dir']}")
    print(f"    - MP4 files:    {config['mp4_dir']}")
    print(f"    - Thumbnails:   {config['thumbnails_dir']}")
    
    if config['install_service']:
        print(f"  - Service name: videostream")
        print(f"  - Service status: {'Running' if config['auto_start'] else 'Not running'}")
    
    print(f"\n{Colors.BOLD}Next Steps:{Colors.ENDC}")
    print(f"  1. Configure application settings through the web interface")
    print(f"  2. Add content and start streaming")
    print(f"  3. Check logs if you encounter any issues: journalctl -u videostream")
    
    return True

def main():
    """Main entry point for the installation script"""
    parser = argparse.ArgumentParser(description='VideoStream CMS Installation Script')
    parser.add_argument('--non-interactive', action='store_true', help='Run installation with default settings')
    parser.add_argument('--config', type=str, help='Path to configuration file (JSON)')
    args = parser.parse_args()
    
    # Check if running as root (recommended for installation)
    if os.geteuid() != 0:
        print(f"{Colors.WARNING}Warning: This script is not running as root. Some operations may fail.{Colors.ENDC}")
        print(f"It is recommended to run this script with sudo.")
        
        continue_as_non_root = input("Continue as non-root user? (y/n) [n]: ")
        if continue_as_non_root.lower() not in ['y', 'yes']:
            print("Exiting. Please run this script with sudo.")
            sys.exit(1)
    
    # Load configuration
    config = DEFAULT_CONFIG.copy()
    
    if args.config:
        try:
            with open(args.config, 'r') as f:
                user_config = json.load(f)
                config.update(user_config)
            print(f"{Colors.GREEN}Loaded configuration from {args.config}{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.FAIL}Error loading configuration file: {str(e)}{Colors.ENDC}")
            if not args.non_interactive:
                print("Falling back to interactive configuration.")
                config = interactive_configuration()
    elif not args.non_interactive:
        config = interactive_configuration()
    
    # Run installation
    if run_installation(config):
        print(f"\n{Colors.GREEN}Thank you for installing VideoStream CMS!{Colors.ENDC}")
    else:
        print(f"\n{Colors.FAIL}Installation may not have completed successfully.{Colors.ENDC}")
        print("Please check the logs and try to resolve any issues.")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())