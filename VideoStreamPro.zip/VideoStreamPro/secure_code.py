import os
import sys
import shutil
import subprocess

def encrypt_project():
    """
    Encrypt the Python code of the VideoStream application using PyArmor.
    This will obfuscate the code and make it difficult for users to read the source.
    """
    print("Starting code encryption process...")
    
    # Create a 'dist' directory for the encrypted files
    if os.path.exists('dist'):
        shutil.rmtree('dist')
    os.makedirs('dist')

    # List of Python files to encrypt
    files_to_encrypt = [
        'app.py',
        'data_manager.py',
        'stream_converter.py',
        'utils.py',
        'video_service.py'
    ]
    
    # Directory to copy static assets
    static_dirs = ['static']
    
    try:
        # Encrypt the files using PyArmor (using the older version command)
        cmd = [
            'pyarmor-7', 'obfuscate',
            '--output', 'dist',
            '--bootstrap', '3',
            '--restrict', '0'
        ] + files_to_encrypt
        
        subprocess.run(cmd, check=True)
        print("Successfully encrypted Python code")
        
        # Copy static directories
        for static_dir in static_dirs:
            if os.path.exists(static_dir):
                dest_dir = os.path.join('dist', static_dir)
                if os.path.exists(dest_dir):
                    shutil.rmtree(dest_dir)
                shutil.copytree(static_dir, dest_dir)
                print(f"Copied {static_dir} directory to dist")
        
        # Create a streamlit run script
        startup_script = """
import streamlit.web.cli as stcli
import sys

if __name__ == "__main__":
    sys.argv = ["streamlit", "run", "app.py", "--server.port=5000", "--server.headless=true", "--server.address=0.0.0.0"]
    sys.exit(stcli.main())
"""
        with open('dist/run_streamlit.py', 'w') as f:
            f.write(startup_script)
        print("Created Streamlit run script")
        
        # Create a README for how to run the encrypted app
        readme = """# VideoStream - Encrypted Version

This is the encrypted version of the VideoStream application.

## How to Run

To run the application, use the following command:

```
cd dist
python run_streamlit.py
```

## Security Notes

1. The code has been obfuscated and encrypted to protect intellectual property
2. Do not modify or delete any files in this directory
3. The license checks may be in place to prevent unauthorized use
"""
        
        with open('dist/README.md', 'w') as f:
            f.write(readme)
        print("Created README file")
        
        print("\nEncryption process completed successfully!")
        print("You can find the encrypted application in the 'dist' directory.")
        print("To run the encrypted app, use: cd dist && python run_streamlit.py")
        
    except Exception as e:
        print(f"Error during encryption: {e}")
        return False
    
    return True

if __name__ == "__main__":
    encrypt_project()