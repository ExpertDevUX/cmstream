import streamlit as st
from deep_translator import GoogleTranslator
import json

def create_thumbnail_link(video_id):
    """
    Create a thumbnail URL for a YouTube video
    
    Args:
        video_id (str): YouTube video ID
        
    Returns:
        str: URL to the video thumbnail
    """
    # YouTube thumbnail URL format
    return f"https://img.youtube.com/vi/{video_id}/mqdefault.jpg"

@st.cache_data(ttl=3600)  # Cache translations for 1 hour
def translate_text(text, language_code):
    """
    Translate text to the specified language
    
    Args:
        text (str): Text to translate
        language_code (str): Language code (EN, VN, CN)
        
    Returns:
        str: Translated text
    """
    # Return original text for empty strings or if already in English
    if not text or language_code == "EN":
        return text
    
    language_map = {
        "VN": "vi",
        "CN": "zh-CN",
        "EN": "en"
    }
    
    target_lang = language_map.get(language_code, "en")
    
    try:
        # If text is too long, truncate it to avoid translation API limits
        if len(text) > 5000:
            text = text[:5000] + "..."
            
        translator = GoogleTranslator(source='auto', target=target_lang)
        translated = translator.translate(text)
        
        # If translation returns None or empty, return original text
        if not translated:
            return text
        
        return translated
    except Exception as e:
        print(f"Translation error: {e}")
        # Return original text on error
        return text

def get_translations(language_code):
    """
    Get translations dictionary for the specified language
    
    Args:
        language_code (str): Language code (EN, VN, CN)
        
    Returns:
        dict: Dictionary of translations
    """
    # English translations (default)
    en_translations = {
        # General UI
        "select_language": "Select Language",
        "menu": "Menu",
        "home": "Home",
        "document": "Documentation",
        "guide": "User Guide",
        "search_videos": "Search Videos",
        "search_placeholder": "Enter keywords to search",
        "search_button": "Search",
        "categories": "Categories",
        "select_category": "Select a category",
        "welcome": "Welcome to VideoStream",
        "search_results_for": "Search Results for",
        "no_videos_found": "No videos found matching your search criteria.",
        "videos": "Videos",
        "no_videos_in_category": "No videos found in the category",
        "trending_videos": "Trending Videos",
        "no_trending_videos": "No trending videos available at the moment.",
        "video_unavailable": "Video not available. It might have been removed or is temporarily unavailable.",
        "back_to_home": "Back to Home",
        
        # Video details
        "description": "Description",
        "details": "Details",
        "views": "Views",
        "likes": "Likes",
        "published": "Published",
        "category": "Category",
        "related_videos": "Related Videos",
        
        # Documentation page
        "documentation": "Documentation",
        "about_videostream": "About VideoStream",
        "about_description": "VideoStream is a modern video streaming platform built with Streamlit. It allows users to browse, search, and watch videos from various categories with a clean and responsive interface.",
        "features": "Features",
        "feature_browse": "Browse Videos",
        "feature_browse_desc": "Discover trending videos and explore different categories.",
        "feature_search": "Search Functionality",
        "feature_search_desc": "Find videos using keywords and phrases.",
        "feature_categories": "Category Navigation",
        "feature_categories_desc": "Browse videos by specific categories of interest.",
        "feature_player": "Video Player",
        "feature_player_desc": "Watch videos with a full-featured embedded player.",
        "feature_translation": "Multi-language Support",
        "feature_translation_desc": "Use the platform in English, Vietnamese, or Chinese with automatic content translation.",
        "privacy_policy": "Privacy Policy",
        "privacy_policy_content": "VideoStream respects your privacy and is committed to protecting your personal data. We collect minimal information necessary to provide our services. We do not sell or share your data with third parties.",
        "terms_of_service": "Terms of Service",
        "terms_of_service_content": "By using VideoStream, you agree to these terms of service. The content provided through our platform is sourced from public APIs and we do not claim ownership of this content. Users are responsible for ensuring their use of our platform complies with applicable laws.",
        
        # User Guide page
        "user_guide": "User Guide",
        "getting_started": "Getting Started",
        "getting_started_content": "Welcome to VideoStream! This guide will help you navigate and get the most out of our platform. VideoStream allows you to discover and watch videos from various categories with a smooth user experience.",
        "searching_videos": "Searching for Videos",
        "searching_videos_content": "To search for videos, use the search box in the sidebar. Enter keywords related to the content you're looking for and click the 'Search' button. The results will display matching videos that you can click to watch.",
        "browsing_categories": "Browsing Categories",
        "browsing_categories_content": "VideoStream organizes content into categories for easy browsing. Select a category from the dropdown menu in the sidebar to see videos specific to that category. You can always return to see all videos by selecting 'All' from the categories.",
        "watching_videos": "Watching Videos",
        "watching_videos_content": "Click on any video thumbnail or title to start watching. The video will play in our embedded player. Below the video, you'll find details about the video and related content recommendations.",
        "language_settings": "Language Settings",
        "language_settings_content": "VideoStream supports multiple languages. You can switch between English, Vietnamese, and Chinese using the language selector in the sidebar. The interface and content will be automatically translated to your chosen language.",
        "troubleshooting": "Troubleshooting",
        "issue_video_not_playing": "Video Not Playing",
        "issue_video_not_playing_solution": "If a video isn't playing, it might be unavailable or removed from the source. Try refreshing the page or selecting a different video.",
        "issue_loading_slow": "Content Loading Slowly",
        "issue_loading_slow_solution": "If the content is loading slowly, it might be due to your internet connection or high traffic on our servers. Try refreshing the page or coming back later.",
        "issue_search_not_working": "Search Not Working",
        "issue_search_not_working_solution": "If search isn't returning expected results, try using different keywords or check your spelling. Also ensure you're connected to the internet.",
        
        # Footer
        "footer_text": "A Streamlit-based Video Platform",
        
        # Donate page
        "donate": "Support VideoStream",
        "scan_qr": "Scan QR Code",
        "download_qr": "Download QR Code",
        "donation_options": "Donation Options",
        "select_amount": "Select Amount",
        "enter_amount": "Enter Amount",
        "your_name": "Your Name (Optional)",
        "message": "Message (Optional)",
        "support_now": "Support Now",
        "donation_thanks": "Thank you for your support! Please complete the payment using the MoMo app by scanning the QR code.",
        "momo_note": "Note: MoMo is a popular mobile payment app in Vietnam. If you don't have the app, you can download it from the App Store or Google Play Store.",
        
        # Stream Converter page
        "stream_converter": "Stream Converter",
        "stream_converter_description": "Convert RTMP streams to HLS, DASH, or MP4 format and generate embed codes for your website.",
        "rtmp_input": "RTMP Stream Input",
        "rtmp_url": "RTMP Stream URL",
        "rtmp_url_help": "Enter your RTMP stream URL (e.g., rtmp://server.com/live/stream-key)",
        "validate_stream": "Validate Stream",
        "validating_stream": "Validating stream...",
        "stream_valid": "Stream is valid and accessible!",
        "stream_invalid": "Could not access the stream. Please check the URL and try again.",
        "generate_preview": "Generate Preview",
        "generating_preview": "Generating preview thumbnail...",
        "preview_success": "Preview generated successfully!",
        "preview_error": "Could not generate preview. Please check the stream.",
        "stream_preview": "Stream Preview",
        "conversion_options": "Conversion Options",
        "select_format": "Select output format",
        "clip_duration": "Clip duration (seconds)",
        "convert_stream": "Convert Stream",
        "converting_stream": "Converting stream...",
        "conversion_success": "Stream converted successfully!",
        "conversion_error": "Conversion failed. Please check the stream URL and try again.",
        "embed_code": "Embed Code",
        "copy_embed_code": "Copy Embed Code",
        "code_copied": "Embed code copied to clipboard!",
        "embedded_player_preview": "Embedded Player Preview",
        
        # Contact page
        "contact": "Contact",
        "contact_description": "Get in touch with our team for any questions, feedback, or support.",
        "contact_name": "Your Name",
        "contact_email": "Your Email",
        "contact_subject": "Subject",
        "contact_message": "Message",
        "contact_submit": "Submit",
        "contact_success": "Thank you for your message! We'll get back to you soon.",
        "contact_information": "Contact Information",
        "contact_email_address": "Email: support@videostream.com",
        "contact_phone": "Phone: +1 (555) 123-4567",
        "contact_address": "Address: 123 Video Street, Stream City, VS 12345",
        "contact_hours": "Business Hours: Monday-Friday, 9:00 AM - 5:00 PM EST",
        
        # Dashboard page
        "dashboard": "Dashboard",
        "project_information": "Project Information",
        "open_source_cms": "VideoStream - Open Source CMS",
        "project_description": "VideoStream is an open-source content management system for video streaming platforms. Built with Streamlit, it provides a modern and customizable solution for creating video streaming websites.",
        "project_version": "Version: 1.0.0",
        "project_license": "License: HWSecurity",
        "project_repository": "GitHub Repository: github.com/videostream/cms",
        "features_overview": "Features Overview",
        "rtmp_conversion": "RTMP Stream Conversion",
        "rtmp_conversion_desc": "Convert RTMP streams to HLS, DASH, or MP4 formats for embedding in websites.",
        "multi_language": "Multi-language Support",
        "multi_language_desc": "Full support for English, Vietnamese, and Chinese languages with automatic translation.",
        "content_management": "Content Management",
        "content_management_desc": "Browse, search, and organize video content by categories.",
        "embedded_player": "Embeddable Player",
        "embedded_player_desc": "Generate embed codes for including videos in external websites.",
        "documentation": "Comprehensive Documentation",
        "documentation_desc": "Detailed user guides and documentation for all features.",
        
        # RTMP Source Generator
        "rtmp_source_generator": "RTMP Source Generator",
        "rtmp_source_description": "Don't have an RTMP stream? Generate a source here to start streaming.",
        "generate_rtmp_source": "Generate RTMP Source",
        "rtmp_source_info": "Your RTMP Stream Source",
        "rtmp_server_url": "RTMP Server URL",
        "rtmp_stream_key": "Stream Key",
        "rtmp_connection_instructions": "Connection Instructions",
        "connect_with_obs": "Connect with OBS Studio",
        "connect_with_wirecast": "Connect with Wirecast",
        "connect_with_vmix": "Connect with vMix",
        "copy_to_clipboard": "Copy to Clipboard",
        "copied_to_clipboard": "Copied to clipboard!",
        "live_preview": "Live Preview",
        "not_streaming": "Not streaming yet. Start your stream using the RTMP URL above."
    }
    
    # Vietnamese translations (hardcoded)
    vn_translations = {
        # General UI
        "select_language": "Chọn Ngôn Ngữ",
        "menu": "Menu",
        "home": "Trang Chủ",
        "document": "Tài Liệu",
        "guide": "Hướng Dẫn Sử Dụng",
        "search_videos": "Tìm Kiếm Video",
        "search_placeholder": "Nhập từ khóa để tìm kiếm",
        "search_button": "Tìm Kiếm",
        "categories": "Danh Mục",
        "select_category": "Chọn một danh mục",
        "welcome": "Chào mừng đến với VideoStream",
        "search_results_for": "Kết quả tìm kiếm cho",
        "no_videos_found": "Không tìm thấy video phù hợp với tiêu chí tìm kiếm của bạn.",
        "videos": "Video",
        "no_videos_in_category": "Không tìm thấy video trong danh mục",
        "trending_videos": "Video Xu Hướng",
        "no_trending_videos": "Hiện không có video xu hướng.",
        "video_unavailable": "Video không khả dụng. Nó có thể đã bị xóa hoặc tạm thời không khả dụng.",
        "back_to_home": "Trở về Trang Chủ",
        
        # Video details
        "description": "Mô Tả",
        "details": "Chi Tiết",
        "views": "Lượt Xem",
        "likes": "Lượt Thích",
        "published": "Đã Đăng",
        "category": "Danh Mục",
        "related_videos": "Video Liên Quan",
        
        # Documentation page
        "documentation": "Tài Liệu",
        "about_videostream": "Giới Thiệu VideoStream",
        "about_description": "VideoStream là một nền tảng phát video hiện đại được xây dựng với Streamlit. Nó cho phép người dùng duyệt, tìm kiếm và xem video từ nhiều danh mục khác nhau với giao diện trực quan.",
        "features": "Tính Năng",
        "feature_browse": "Duyệt Video",
        "feature_browse_desc": "Khám phá video xu hướng và các danh mục khác nhau.",
        "feature_search": "Chức Năng Tìm Kiếm",
        "feature_search_desc": "Tìm video bằng từ khóa và cụm từ.",
        "feature_categories": "Điều Hướng Danh Mục",
        "feature_categories_desc": "Duyệt video theo các danh mục cụ thể.",
        "feature_player": "Trình Phát Video",
        "feature_player_desc": "Xem video với trình phát đầy đủ tính năng.",
        "feature_translation": "Hỗ Trợ Đa Ngôn Ngữ",
        "feature_translation_desc": "Sử dụng nền tảng bằng tiếng Anh, tiếng Việt hoặc tiếng Trung với dịch tự động.",
        "privacy_policy": "Chính Sách Bảo Mật",
        "privacy_policy_content": "VideoStream tôn trọng quyền riêng tư của bạn và cam kết bảo vệ dữ liệu cá nhân. Chúng tôi chỉ thu thập thông tin cần thiết để cung cấp dịch vụ và không bán hoặc chia sẻ dữ liệu với bên thứ ba.",
        "terms_of_service": "Điều Khoản Dịch Vụ",
        "terms_of_service_content": "Khi sử dụng VideoStream, bạn đồng ý với các điều khoản dịch vụ này. Nội dung được cung cấp qua nền tảng của chúng tôi được lấy từ các API công khai và chúng tôi không tuyên bố sở hữu nội dung này.",
        
        # Donate page
        "donate": "Ủng Hộ VideoStream",
        "scan_qr": "Quét Mã QR",
        "download_qr": "Tải Xuống Mã QR",
        "donation_options": "Lựa Chọn Ủng Hộ",
        "select_amount": "Chọn Số Tiền",
        "enter_amount": "Nhập Số Tiền",
        "your_name": "Tên Của Bạn (Tùy Chọn)",
        "message": "Lời Nhắn (Tùy Chọn)",
        "support_now": "Ủng Hộ Ngay",
        "donation_thanks": "Cảm ơn sự ủng hộ của bạn! Vui lòng hoàn tất thanh toán bằng ứng dụng MoMo bằng cách quét mã QR.",
        "momo_note": "Lưu ý: MoMo là ứng dụng thanh toán di động phổ biến tại Việt Nam. Nếu bạn chưa có ứng dụng, bạn có thể tải xuống từ App Store hoặc Google Play Store.",
        
        # Stream Converter page
        "stream_converter": "Chuyển Đổi Luồng",
        "stream_converter_description": "Chuyển đổi luồng RTMP sang định dạng HLS, DASH hoặc MP4 và tạo mã nhúng cho trang web của bạn.",
        "rtmp_input": "Đầu Vào Luồng RTMP",
        "rtmp_url": "URL Luồng RTMP",
        "rtmp_url_help": "Nhập URL luồng RTMP của bạn (ví dụ: rtmp://server.com/live/stream-key)",
        "validate_stream": "Xác Thực Luồng",
        "validating_stream": "Đang xác thực luồng...",
        "stream_valid": "Luồng hợp lệ và có thể truy cập!",
        "stream_invalid": "Không thể truy cập luồng. Vui lòng kiểm tra URL và thử lại.",
        "generate_preview": "Tạo Bản Xem Trước",
        "generating_preview": "Đang tạo hình thu nhỏ xem trước...",
        "preview_success": "Đã tạo bản xem trước thành công!",
        "preview_error": "Không thể tạo bản xem trước. Vui lòng kiểm tra luồng.",
        "stream_preview": "Xem Trước Luồng",
        "conversion_options": "Tùy Chọn Chuyển Đổi",
        "select_format": "Chọn định dạng đầu ra",
        "clip_duration": "Thời lượng clip (giây)",
        "convert_stream": "Chuyển Đổi Luồng",
        "converting_stream": "Đang chuyển đổi luồng...",
        "conversion_success": "Đã chuyển đổi luồng thành công!",
        "conversion_error": "Chuyển đổi thất bại. Vui lòng kiểm tra URL luồng và thử lại.",
        "embed_code": "Mã Nhúng",
        "copy_embed_code": "Sao Chép Mã Nhúng",
        "code_copied": "Đã sao chép mã nhúng vào clipboard!",
        "embedded_player_preview": "Xem Trước Trình Phát Nhúng",
        
        # RTMP Source Generator
        "rtmp_source_generator": "Tạo Nguồn RTMP",
        "rtmp_source_description": "Không có luồng RTMP? Tạo một nguồn tại đây để bắt đầu phát trực tuyến.",
        "generate_rtmp_source": "Tạo Nguồn RTMP",
        "rtmp_source_info": "Nguồn Luồng RTMP Của Bạn",
        "rtmp_server_url": "URL Máy Chủ RTMP",
        "rtmp_stream_key": "Khóa Luồng",
        "rtmp_connection_instructions": "Hướng Dẫn Kết Nối",
        "connect_with_obs": "Kết nối với OBS Studio",
        "connect_with_wirecast": "Kết nối với Wirecast",
        "connect_with_vmix": "Kết nối với vMix",
        "copy_to_clipboard": "Sao chép",
        "copied_to_clipboard": "Đã sao chép vào clipboard!",
        "live_preview": "Xem Trước Trực Tiếp",
        "not_streaming": "Chưa phát trực tuyến. Bắt đầu luồng của bạn bằng URL RTMP ở trên."
    }
    
    # Chinese translations (hardcoded)
    cn_translations = {
        # General UI
        "select_language": "选择语言",
        "menu": "菜单",
        "home": "首页",
        "document": "文档",
        "guide": "用户指南",
        "search_videos": "搜索视频",
        "search_placeholder": "输入关键词搜索",
        "search_button": "搜索",
        "categories": "分类",
        "select_category": "选择一个分类",
        "welcome": "欢迎使用 VideoStream",
        "search_results_for": "搜索结果",
        "no_videos_found": "没有找到符合您搜索条件的视频。",
        "videos": "视频",
        "no_videos_in_category": "该分类中没有视频",
        "trending_videos": "热门视频",
        "no_trending_videos": "目前没有热门视频。",
        "video_unavailable": "视频不可用。它可能已被删除或暂时不可用。",
        "back_to_home": "返回首页",
        
        # Video details
        "description": "描述",
        "details": "详情",
        "views": "观看次数",
        "likes": "喜欢",
        "published": "发布时间",
        "category": "分类",
        "related_videos": "相关视频",
        
        # Documentation page
        "documentation": "文档",
        "about_videostream": "关于 VideoStream",
        "about_description": "VideoStream 是一个基于 Streamlit 构建的现代视频流平台。它允许用户浏览、搜索和观看来自各种分类的视频，具有清晰响应的界面。",
        "features": "功能",
        "feature_browse": "浏览视频",
        "feature_browse_desc": "发现热门视频并探索不同分类。",
        "feature_search": "搜索功能",
        "feature_search_desc": "使用关键词和短语查找视频。",
        "feature_categories": "分类导航",
        "feature_categories_desc": "按特定感兴趣的分类浏览视频。",
        "feature_player": "视频播放器",
        "feature_player_desc": "使用功能齐全的嵌入式播放器观看视频。",
        "feature_translation": "多语言支持",
        "feature_translation_desc": "使用英文、越南文或中文与自动翻译功能使用平台。",
        "privacy_policy": "隐私政策",
        "privacy_policy_content": "VideoStream 尊重您的隐私并致力于保护您的个人数据。我们只收集提供服务所需的最少信息。我们不会出售或与第三方分享您的数据。",
        "terms_of_service": "服务条款",
        "terms_of_service_content": "使用 VideoStream 即表示您同意这些服务条款。通过我们平台提供的内容来源于公共 API，我们不声称拥有此内容的所有权。用户负责确保其使用我们的平台符合适用法律。",
        
        # Donate page
        "donate": "支持 VideoStream",
        "scan_qr": "扫描二维码",
        "download_qr": "下载二维码",
        "donation_options": "捐赠选项",
        "select_amount": "选择金额",
        "enter_amount": "输入金额",
        "your_name": "您的姓名（可选）",
        "message": "留言（可选）",
        "support_now": "立即支持",
        "donation_thanks": "感谢您的支持！请使用MoMo应用扫描二维码完成付款。",
        "momo_note": "注意：MoMo是越南流行的移动支付应用。如果您没有该应用，可以从App Store或Google Play商店下载。",
        
        # Stream Converter page
        "stream_converter": "流转换器",
        "stream_converter_description": "将 RTMP 流转换为 HLS、DASH 或 MP4 格式，并为您的网站生成嵌入代码。",
        "rtmp_input": "RTMP 流输入",
        "rtmp_url": "RTMP 流 URL",
        "rtmp_url_help": "输入您的 RTMP 流 URL（例如：rtmp://server.com/live/stream-key）",
        "validate_stream": "验证流",
        "validating_stream": "正在验证流...",
        "stream_valid": "流有效且可访问！",
        "stream_invalid": "无法访问流。请检查 URL 并重试。",
        "generate_preview": "生成预览",
        "generating_preview": "正在生成预览缩略图...",
        "preview_success": "预览生成成功！",
        "preview_error": "无法生成预览。请检查流。",
        "stream_preview": "流预览",
        "conversion_options": "转换选项",
        "select_format": "选择输出格式",
        "clip_duration": "剪辑时长（秒）",
        "convert_stream": "转换流",
        "converting_stream": "正在转换流...",
        "conversion_success": "流转换成功！",
        "conversion_error": "转换失败。请检查流 URL 并重试。",
        "embed_code": "嵌入代码",
        "copy_embed_code": "复制嵌入代码",
        "code_copied": "嵌入代码已复制到剪贴板！",
        "embedded_player_preview": "嵌入式播放器预览",
        
        # RTMP Source Generator
        "rtmp_source_generator": "RTMP 源生成器",
        "rtmp_source_description": "没有 RTMP 流？在这里生成一个源开始流媒体传输。",
        "generate_rtmp_source": "生成 RTMP 源",
        "rtmp_source_info": "您的 RTMP 流源",
        "rtmp_server_url": "RTMP 服务器 URL",
        "rtmp_stream_key": "流密钥",
        "rtmp_connection_instructions": "连接说明",
        "connect_with_obs": "与 OBS Studio 连接",
        "connect_with_wirecast": "与 Wirecast 连接",
        "connect_with_vmix": "与 vMix 连接",
        "copy_to_clipboard": "复制",
        "copied_to_clipboard": "已复制到剪贴板！",
        "live_preview": "实时预览",
        "not_streaming": "尚未开始流媒体。使用上面的 RTMP URL 开始您的流。"
    }
    
    # Return the appropriate translations based on language code
    if language_code == "EN":
        return en_translations
    elif language_code == "VN":
        return vn_translations
    elif language_code == "CN":
        return cn_translations
    else:
        # Default to English if an unsupported language code is provided
        return en_translations