import pandas as pd
import streamlit as st

@st.cache_data(ttl=86400)  # Cache for 24 hours
def get_categories():
    """
    Get a list of video categories
    
    Returns:
        list: List of category names
    """
    # Standard categories for video content
    categories = [
        "All",
        "Music",
        "Gaming",
        "Sports",
        "News",
        "Technology",
        "Entertainment",
        "Education",
        "Science",
        "Travel",
        "Cooking",
        "Fashion",
        "Comedy",
        "Fitness",
        "DIY & Crafts"
    ]
    
    return categories
